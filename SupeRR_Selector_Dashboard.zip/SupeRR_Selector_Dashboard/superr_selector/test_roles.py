import pandas as pd
import numpy as np

p = r'C:\Users\mishr\.gemini\antigravity\scratch\superr_selector\Data Pack'
bbb = pd.read_csv(f'{p}/ball_by_ball.csv')
p11 = pd.read_csv(f'{p}/playing_eleven.csv')
mapping = pd.read_csv(f'{p}/competition_team_player_mapping.csv')

# Unique players
players = mapping[['player_id', 'player_name']].drop_duplicates().set_index('player_id')

# Total balls faced and bowled
bf = bbb[bbb['extras_type'] != 'wide'].groupby('striker_id').size().rename('balls_faced')
bb = bbb[~bbb['extras_type'].isin(['wide', 'Overstep', 'other'])].groupby('bowler_id').size().rename('balls_bowled')
wk = p11[p11['is_wk'] == True]['player_id'].unique()
avg_order = p11[p11['is_played'] == 1].groupby('player_id')['batting_order'].mean().rename('avg_order')

p_summary = players.join(bf, how='left').join(bb, how='left').join(avg_order, how='left').fillna({'balls_faced': 0, 'balls_bowled': 0, 'avg_order': 8})
p_summary['is_wk'] = p_summary.index.isin(wk)

def assign_role(row):
    if row['is_wk']:
        return 'WK-Batter'
    if row['balls_faced'] >= 100 and row['balls_bowled'] >= 100:
        return 'All-Rounder'
    if row['balls_faced'] > row['balls_bowled'] * 1.5:
        if row['avg_order'] <= 3.5:
            return 'Top-Order Batter'
        elif row['avg_order'] <= 6.5:
            return 'Middle-Order Batter'
        else:
            return 'Batter'
    elif row['balls_bowled'] > 0:
        return 'Bowler'
    else:
        return 'Batter'

p_summary['role'] = p_summary.apply(assign_role, axis=1)
print(p_summary['role'].value_counts())
print("\nSample player roles:")
sample_names = ['Suryakumar Yadav', 'Heinrich Klaasen', 'Jasprit Bumrah', 'Rashid Khan', 'Hardik Pandya', 'Rinku Singh', 'Sanju Samson']
print(p_summary[p_summary['player_name'].isin(sample_names)][['player_name', 'role', 'balls_faced', 'balls_bowled', 'is_wk']])
