"""
Reliability Scoring Models for Batting and Bowling under pressure.
SupeRR Selector Season 2 - Round 1
"""

import sys
import os
pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if pkg_root not in sys.path:
    sys.path.insert(0, pkg_root)

import pandas as pd
import numpy as np
from src.config import (
    BATTING_MIN_PRESSURE_BALLS,
    BATTING_MIN_TOTAL_BALLS,
    BOWLING_MIN_PRESSURE_BALLS,
    BOWLING_MIN_TOTAL_BALLS,
    BAYES_PRIOR_BALLS_BAT,
    BAYES_PRIOR_BALLS_BOWL
)

def zscore(series):
    """Calculates standardized Z-score handling constant series."""
    std = series.std()
    if std == 0 or pd.isna(std):
        return series - series.mean()
    return (series - series.mean()) / std

def calculate_batting_rankings(
    deliveries_df,
    player_meta_df,
    min_pressure_balls=BATTING_MIN_PRESSURE_BALLS,
    min_total_balls=BATTING_MIN_TOTAL_BALLS,
    bayes_prior=BAYES_PRIOR_BALLS_BAT
):
    """
    Computes Batting Reliability Score (BRS) and rankings.
    Returns:
        DataFrame: Ranked table of qualified batters with all pressure, normal,
                   delta, consistency, and scoring metrics.
    """
    df = deliveries_df

    # Match-level consistency under pressure
    # An impact match in pressure: scored >= 20 runs OR (faced >= 8 balls with SR >= 140)
    p_match = df[df["is_pressure"]].groupby(["match_id", "striker_id", "striker_name"]).agg(
        p_runs=("runs", "sum"),
        p_balls=("is_batter_ball", "sum")
    ).reset_index()

    p_match["is_impact"] = (p_match["p_runs"] >= 20) | (
        (p_match["p_balls"] >= 8) & ((p_match["p_runs"] / p_match["p_balls"]) >= 1.40)
    )

    consistency = p_match.groupby(["striker_id", "striker_name"]).agg(
        pressure_matches=("match_id", "nunique"),
        impact_matches=("is_impact", "sum")
    ).reset_index()
    consistency["consistency_rate"] = (consistency["impact_matches"] / consistency["pressure_matches"]) * 100.0

    # Aggregate Batting Stats for given subset
    def agg_batting_subset(sub_df):
        grp = sub_df.groupby(["striker_id", "striker_name"])
        runs = grp["runs"].sum()
        balls = grp["is_batter_ball"].sum()
        dots = grp["is_dot_batter"].sum()
        fours = grp["is_four"].sum()
        sixes = grp["is_six"].sum()

        outs = sub_df[sub_df["is_wicket"] & (sub_df["dismissed_player_id"] == sub_df["striker_id"])].groupby(
            ["striker_id", "striker_name"]
        ).size()

        res = pd.DataFrame({
            "runs": runs,
            "balls": balls,
            "dots": dots,
            "fours": fours,
            "sixes": sixes
        }).join(outs.rename("outs"), how="left").fillna(0)

        res["sr"] = (res["runs"] / res["balls"].replace(0, np.nan)) * 100.0
        res["avg"] = res["runs"] / res["outs"].replace(0, 1.0)
        res["dot_pct"] = (res["dots"] / res["balls"].replace(0, np.nan)) * 100.0
        res["bdry_pct"] = ((res["fours"] + res["sixes"]) / res["balls"].replace(0, np.nan)) * 100.0
        res["bdry_run_pct"] = ((res["fours"] * 4 + res["sixes"] * 6) / res["runs"].replace(0, np.nan)) * 100.0
        return res

    bat_p = agg_batting_subset(df[df["is_pressure"]])
    bat_n = agg_batting_subset(df[~df["is_pressure"]])

    merged = bat_p.join(bat_n, lsuffix="_pres", rsuffix="_norm", how="inner").reset_index()
    merged = merged.merge(consistency, on=["striker_id", "striker_name"], how="left")
    merged = merged.merge(player_meta_df[["player_id", "role", "is_rr"]], left_on="striker_id", right_on="player_id", how="left")

    merged["total_balls"] = merged["balls_pres"] + merged["balls_norm"]
    merged["total_runs"] = merged["runs_pres"] + merged["runs_norm"]

    # Filter qualifiers
    qual = merged[
        (merged["balls_pres"] >= min_pressure_balls) &
        (merged["total_balls"] >= min_total_balls)
    ].copy()

    if len(qual) == 0:
        return pd.DataFrame()

    # Differential Metrics
    qual["delta_sr"] = qual["sr_pres"] - qual["sr_norm"]
    qual["delta_avg"] = qual["avg_pres"] - qual["avg_norm"]
    qual["delta_dot"] = qual["dot_pct_norm"] - qual["dot_pct_pres"] # positive is reduction in dots

    # 1. Pressure Performance Index (40%)
    z_sr_p = zscore(qual["sr_pres"])
    z_avg_p = zscore(qual["avg_pres"])
    z_bdry_p = zscore(qual["bdry_pct_pres"])
    z_dot_p = -zscore(qual["dot_pct_pres"]) # fewer dots = better
    score_perf = 0.35 * z_sr_p + 0.35 * z_avg_p + 0.15 * z_bdry_p + 0.15 * z_dot_p

    # 2. Clutch Differential Index (30%)
    z_dsr = zscore(qual["delta_sr"])
    z_davg = zscore(qual["delta_avg"])
    z_ddot = zscore(qual["delta_dot"])
    score_delta = 0.40 * z_dsr + 0.40 * z_davg + 0.20 * z_ddot

    # 3. Match-to-Match Consistency Index (20%)
    z_const = zscore(qual["consistency_rate"].fillna(qual["consistency_rate"].mean()))

    # Raw composite score
    raw_composite = 0.45 * score_perf + 0.30 * score_delta + 0.25 * z_const

    # 4. Bayesian Sample Size Credibility Factor (10% weight via shrinkage)
    # w = N / (N + N0)
    w_cred = qual["balls_pres"] / (qual["balls_pres"] + bayes_prior)
    qual["credibility_weight"] = w_cred
    qual["raw_brs"] = w_cred * raw_composite

    # Scale to 0 - 100 for intuitive presentation (calibrated with 50 as baseline)
    min_s = qual["raw_brs"].min()
    max_s = qual["raw_brs"].max()
    if max_s > min_s:
        qual["reliability_score"] = ((qual["raw_brs"] - min_s) / (max_s - min_s) * 45.0 + 55.0).round(2)
    else:
        qual["reliability_score"] = 75.0

    qual = qual.sort_values("reliability_score", ascending=False).reset_index(drop=True)
    qual["rank"] = range(1, len(qual) + 1)
    return qual

def calculate_bowling_rankings(
    deliveries_df,
    player_meta_df,
    min_pressure_balls=BOWLING_MIN_PRESSURE_BALLS,
    min_total_balls=BOWLING_MIN_TOTAL_BALLS,
    bayes_prior=BAYES_PRIOR_BALLS_BOWL
):
    """
    Computes Bowling Reliability Score (BowRS) and rankings.
    Returns:
        DataFrame: Ranked table of qualified bowlers with all pressure, normal,
                   delta, consistency, death-overs and scoring metrics.
    """
    df = deliveries_df

    # Match-level consistency under pressure
    # Bowler impact in pressure: took >= 1 wicket OR bowled >= 12 balls with economy <= 8.0
    p_match = df[df["is_pressure"]].groupby(["match_id", "bowler_id", "bowler_name"]).agg(
        p_runs=("bowler_runs_conceded", "sum"),
        p_balls=("is_legal", "sum"),
        p_wkts=("is_bowler_wicket", "sum")
    ).reset_index()

    p_match["is_impact"] = (p_match["p_wkts"] >= 1) | (
        (p_match["p_balls"] >= 12) & ((p_match["p_runs"] / (p_match["p_balls"] / 6.0)) <= 8.0)
    )

    consistency = p_match.groupby(["bowler_id", "bowler_name"]).agg(
        pressure_matches=("match_id", "nunique"),
        impact_matches=("is_impact", "sum")
    ).reset_index()
    consistency["consistency_rate"] = (consistency["impact_matches"] / consistency["pressure_matches"]) * 100.0

    # Death overs specific stats (overs 16-20 under pressure)
    death_df = df[df["is_pressure"] & (df["overid"] >= 16)]
    death_grp = death_df.groupby(["bowler_id", "bowler_name"]).agg(
        death_balls=("is_legal", "sum"),
        death_runs=("bowler_runs_conceded", "sum"),
        death_wkts=("is_bowler_wicket", "sum"),
        death_dots=("is_dot_bowler", "sum")
    ).reset_index()
    death_grp["death_overs"] = death_grp["death_balls"] / 6.0
    death_grp["death_econ"] = death_grp["death_runs"] / death_grp["death_overs"].replace(0, np.nan)
    death_grp["death_dot_pct"] = (death_grp["death_dots"] / death_grp["death_balls"].replace(0, np.nan)) * 100.0

    # Aggregate Bowling Stats for given subset
    def agg_bowling_subset(sub_df):
        grp = sub_df.groupby(["bowler_id", "bowler_name"])
        runs = grp["bowler_runs_conceded"].sum()
        balls = grp["is_legal"].sum()
        dots = grp["is_dot_bowler"].sum()
        fours = grp["is_four"].sum()
        sixes = grp["is_six"].sum()
        wkts = grp["is_bowler_wicket"].sum()

        res = pd.DataFrame({
            "runs_conceded": runs,
            "legal_balls": balls,
            "dots": dots,
            "fours_conceded": fours,
            "sixes_conceded": sixes,
            "wickets": wkts
        })

        res["overs"] = res["legal_balls"] / 6.0
        res["econ"] = res["runs_conceded"] / res["overs"].replace(0, np.nan)
        res["avg"] = res["runs_conceded"] / res["wickets"].replace(0, 1.0)
        res["sr"] = res["legal_balls"] / res["wickets"].replace(0, np.nan)
        res["dot_pct"] = (res["dots"] / res["legal_balls"].replace(0, np.nan)) * 100.0
        res["bdry_pct"] = ((res["fours_conceded"] + res["sixes_conceded"]) / res["legal_balls"].replace(0, np.nan)) * 100.0
        return res

    bowl_p = agg_bowling_subset(df[df["is_pressure"]])
    bowl_n = agg_bowling_subset(df[~df["is_pressure"]])

    merged = bowl_p.join(bowl_n, lsuffix="_pres", rsuffix="_norm", how="inner").reset_index()
    merged = merged.merge(consistency, on=["bowler_id", "bowler_name"], how="left")
    merged = merged.merge(death_grp[["bowler_id", "bowler_name", "death_balls", "death_econ", "death_wkts", "death_dot_pct"]], on=["bowler_id", "bowler_name"], how="left")
    merged = merged.merge(player_meta_df[["player_id", "role", "is_rr"]], left_on="bowler_id", right_on="player_id", how="left")

    merged["total_balls"] = merged["legal_balls_pres"] + merged["legal_balls_norm"]
    merged["total_wickets"] = merged["wickets_pres"] + merged["wickets_norm"]

    # Filter qualifiers
    qual = merged[
        (merged["legal_balls_pres"] >= min_pressure_balls) &
        (merged["total_balls"] >= min_total_balls)
    ].copy()

    if len(qual) == 0:
        return pd.DataFrame()

    # Differential Metrics
    qual["delta_econ"] = qual["econ_norm"] - qual["econ_pres"] # positive means conceded fewer runs under pressure
    qual["delta_dot"] = qual["dot_pct_pres"] - qual["dot_pct_norm"] # positive means more dots under pressure
    qual["delta_wkt_rate"] = (qual["wickets_pres"] / qual["legal_balls_pres"]) - (qual["wickets_norm"] / qual["legal_balls_norm"])

    # 1. Pressure Performance Index (40%)
    z_econ_p = -zscore(qual["econ_pres"]) # lower econ = higher score
    z_wkts_p = zscore(qual["wickets_pres"] / qual["legal_balls_pres"])
    z_dot_p = zscore(qual["dot_pct_pres"])
    z_bdry_p = -zscore(qual["bdry_pct_pres"])
    score_perf = 0.35 * z_econ_p + 0.30 * z_wkts_p + 0.20 * z_dot_p + 0.15 * z_bdry_p

    # 2. Clutch Differential Index (30%)
    z_decon = zscore(qual["delta_econ"])
    z_ddot = zscore(qual["delta_dot"])
    z_dwkt = zscore(qual["delta_wkt_rate"])
    score_delta = 0.45 * z_decon + 0.30 * z_ddot + 0.25 * z_dwkt

    # 3. Match Consistency & Death Overs Index (20%)
    z_const = zscore(qual["consistency_rate"].fillna(qual["consistency_rate"].mean()))

    # Raw composite score
    raw_composite = 0.45 * score_perf + 0.30 * score_delta + 0.25 * z_const

    # 4. Bayesian Credibility Shrinkage (10% weight)
    w_cred = qual["legal_balls_pres"] / (qual["legal_balls_pres"] + bayes_prior)
    qual["credibility_weight"] = w_cred
    qual["raw_score"] = w_cred * raw_composite

    # Scale to 0 - 100
    min_s = qual["raw_score"].min()
    max_s = qual["raw_score"].max()
    if max_s > min_s:
        qual["reliability_score"] = ((qual["raw_score"] - min_s) / (max_s - min_s) * 45.0 + 55.0).round(2)
    else:
        qual["reliability_score"] = 75.0

    qual = qual.sort_values("reliability_score", ascending=False).reset_index(drop=True)
    qual["rank"] = range(1, len(qual) + 1)
    return qual

if __name__ == "__main__":
    from src.data_engine import DATA_PROCESSED_DIR
    bbb = pd.read_parquet(os.path.join(DATA_PROCESSED_DIR, "deliveries_processed.parquet"))
    pmeta = pd.read_parquet(os.path.join(DATA_PROCESSED_DIR, "players_meta.parquet"))
    
    bat_rank = calculate_batting_rankings(bbb, pmeta)
    print("Batting Rankings Top 10:")
    print(bat_rank[["rank", "striker_name", "role", "reliability_score", "runs_pres", "balls_pres", "sr_pres", "avg_pres"]].head(10))
    
    bowl_rank = calculate_bowling_rankings(bbb, pmeta)
    print("\nBowling Rankings Top 10:")
    print(bowl_rank[["rank", "bowler_name", "role", "reliability_score", "wickets_pres", "legal_balls_pres", "econ_pres", "avg_pres"]].head(10))
