"""
Data Engineering and Pressure Classification Engine for SupeRR Selector.
Processes ball-by-ball delivery records and match contexts to generate
analytical datasets for batting and bowling under pressure.
"""

import os
import sys
pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if pkg_root not in sys.path:
    sys.path.insert(0, pkg_root)

import pandas as pd
import numpy as np
from src.config import DATA_RAW_DIR, DATA_PROCESSED_DIR

def load_and_preprocess_raw_data(data_dir=DATA_RAW_DIR):
    """Loads raw CSVs and merges match, competition, and player metadata."""
    print("Loading raw CSV files...")
    bbb = pd.read_csv(os.path.join(data_dir, "ball_by_ball.csv"))
    matches = pd.read_csv(os.path.join(data_dir, "matches.csv"))
    comps = pd.read_csv(os.path.join(data_dir, "competitions.csv"))
    p11 = pd.read_csv(os.path.join(data_dir, "playing_eleven.csv"))
    mapping = pd.read_csv(os.path.join(data_dir, "competition_team_player_mapping.csv"))

    # Link competition metadata into matches
    matches = matches.merge(
        comps[["comp_id", "match_format", "season", "comp_name"]],
        on="comp_id",
        how="left"
    )
    matches_dict = matches.set_index("match_id").to_dict(orient="index")

    # Delivery-level indicators
    bbb["ball_runs_total"] = bbb["runs"] + bbb["extras1_runs"] + bbb["extras_2_runs"]
    bbb["is_legal"] = ~bbb["extras_type"].isin(["wide", "Overstep", "other"])
    bbb["is_batter_ball"] = bbb["extras_type"] != "wide"
    bbb["is_dot_batter"] = (bbb["runs"] == 0) & bbb["is_batter_ball"]

    # Bowler runs conceded calculation
    def get_bowler_runs(row):
        ext = row["extras_type"]
        if pd.isna(ext):
            return row["runs"]
        elif ext == "wide":
            return row["extras1_runs"]
        elif ext in ["Overstep", "other"]:
            return row["runs"] + row["extras1_runs"]
        else: # legbyes, byes, penalty
            return 0

    bbb["bowler_runs_conceded"] = [get_bowler_runs(r) for _, r in bbb.iterrows()]
    bbb["is_bowler_wicket"] = bbb["is_wicket"] & bbb["dismissal_type"].isin(
        ["Caught", "Bowled", "LBW", "Stump", "Hit Wicket"]
    )
    bbb["is_dot_bowler"] = bbb["is_legal"] & (bbb["bowler_runs_conceded"] == 0)

    # Sort strictly by delivery sequence
    bbb = bbb.sort_values(["match_id", "innings", "overid", "over_ball_num"]).reset_index(drop=True)

    # Calculate cumulative state
    print("Calculating live match state at each delivery...")
    bbb["cum_runs"] = bbb.groupby(["match_id", "innings"])["ball_runs_total"].cumsum() - bbb["ball_runs_total"]
    bbb["cum_legal_balls"] = bbb.groupby(["match_id", "innings"])["is_legal"].cumsum() - bbb["is_legal"].astype(int)
    bbb["cum_wickets"] = bbb.groupby(["match_id", "innings"])["is_wicket"].cumsum() - bbb["is_wicket"].astype(int)

    # 1st Innings total for target determination
    inn1_totals = bbb[bbb["innings"] == 1].groupby("match_id")["ball_runs_total"].sum().to_dict()

    # Pressure classification logic
    def classify_delivery(row):
        mid = row["match_id"]
        m_info = matches_dict.get(mid, {})
        is_ko = m_info.get("knock_out", 0) == 1
        inn = row["innings"]
        over = row["overid"]
        cum_w = row["cum_wickets"]
        balls_bowled = row["cum_legal_balls"]
        balls_rem = max(0, 120 - balls_bowled)

        if inn == 1:
            if balls_bowled <= 36 and cum_w >= 3:
                return True, "Inn1 Collapse (Powerplay)"
            if balls_bowled <= 60 and cum_w >= 4:
                return True, "Inn1 Collapse (Middle)"
            if over >= 17:
                return True, "Inn1 Death Overs (17-20)"
            if is_ko and over >= 15 and cum_w >= 3:
                return True, "Inn1 Knockout Crunch"
            return False, "Inn1 Normal"

        elif inn == 2:
            target = m_info.get("revised_target")
            if pd.isna(target) or target == 0:
                target = inn1_totals.get(mid, 0) + 1

            runs_needed = max(0, target - row["cum_runs"])
            if runs_needed <= 0 or balls_rem <= 0:
                return False, "Inn2 Decided"

            rrr = (runs_needed * 6.0) / max(1, balls_rem)
            if balls_rem <= 60 and rrr >= 9.5:
                return True, "Inn2 Steep RRR (>=9.5)"
            if balls_bowled > 36 and rrr >= 11.0:
                return True, "Inn2 Extreme RRR (>=11.0)"
            if over >= 16 and runs_needed > 0 and rrr <= 24.0:
                return True, "Inn2 Death Overs"
            if balls_bowled <= 36 and cum_w >= 3:
                return True, "Inn2 Chase Collapse"
            if cum_w >= 6 and runs_needed > 15:
                return True, "Inn2 Lower Order Pressure"
            if is_ko and over >= 14 and rrr >= 8.5:
                return True, "Inn2 Knockout Chase"
            return False, "Inn2 Normal"

        return False, "Super Over / Other"

    classification_results = [classify_delivery(row) for _, row in bbb.iterrows()]
    bbb["is_pressure"] = [r[0] for r in classification_results]
    bbb["pressure_tag"] = [r[1] for r in classification_results]

    # Attach match meta
    bbb["match_format"] = bbb["match_id"].map(lambda mid: matches_dict.get(mid, {}).get("match_format", "Unknown"))
    bbb["season"] = bbb["match_id"].map(lambda mid: str(matches_dict.get(mid, {}).get("season", "Unknown")))
    bbb["comp_name"] = bbb["match_id"].map(lambda mid: matches_dict.get(mid, {}).get("comp_name", "Unknown"))
    bbb["is_knockout"] = bbb["match_id"].map(lambda mid: matches_dict.get(mid, {}).get("knock_out", 0) == 1)

    # Determine Player Roles
    print("Assigning player roles and Rajasthan Royals affiliations...")
    wk_players = set(p11[p11["is_wk"] == True]["player_id"].unique())
    played_p11 = p11[p11["is_played"] == 1]
    avg_bat_order = played_p11.groupby("player_id")["batting_order"].mean().to_dict()

    career_bf = bbb[bbb["is_batter_ball"]].groupby("striker_id").size().to_dict()
    career_bb = bbb[bbb["is_legal"]].groupby("bowler_id").size().to_dict()

    # Rajasthan Royals player set
    rr_players = set(mapping[mapping["team_id"] == 3]["player_id"].unique())

    all_pids = set(bbb["striker_id"]).union(set(bbb["bowler_id"]))
    pid_to_name = {}
    for _, r in bbb[["striker_id", "striker_name"]].drop_duplicates().iterrows():
        pid_to_name[r["striker_id"]] = r["striker_name"]
    for _, r in bbb[["bowler_id", "bowler_name"]].drop_duplicates().iterrows():
        pid_to_name[r["bowler_id"]] = r["bowler_name"]

    player_roles = {}
    for pid in all_pids:
        is_wk = pid in wk_players
        bf = career_bf.get(pid, 0)
        bb_count = career_bb.get(pid, 0)
        ord_val = avg_bat_order.get(pid, 8.0)

        if is_wk:
            role = "WK-Batter"
        elif bf >= 100 and bb_count >= 100:
            role = "All-Rounder"
        elif bf > bb_count * 1.5:
            if ord_val <= 3.5:
                role = "Top-Order Batter"
            elif ord_val <= 6.5:
                role = "Middle-Order Batter"
            else:
                role = "Batter"
        elif bb_count > 0:
            role = "Bowler"
        else:
            role = "Batter"
        player_roles[pid] = role

    player_meta_df = pd.DataFrame([
        {
            "player_id": pid,
            "player_name": pid_to_name.get(pid, "Unknown"),
            "role": player_roles.get(pid, "Player"),
            "is_rr": pid in rr_players,
            "career_balls_faced": career_bf.get(pid, 0),
            "career_balls_bowled": career_bb.get(pid, 0)
        }
        for pid in all_pids
    ])

    return bbb, matches, comps, player_meta_df

def save_processed_data(bbb, matches, comps, player_meta_df, output_dir=DATA_PROCESSED_DIR):
    """Saves processed datasets to parquet files for ultra-fast loading."""
    os.makedirs(output_dir, exist_ok=True)
    print(f"Saving processed data to {output_dir}...")
    bbb.to_parquet(os.path.join(output_dir, "deliveries_processed.parquet"), index=False)
    matches.to_parquet(os.path.join(output_dir, "matches_processed.parquet"), index=False)
    comps.to_parquet(os.path.join(output_dir, "competitions_processed.parquet"), index=False)
    player_meta_df.to_parquet(os.path.join(output_dir, "players_meta.parquet"), index=False)
    print("All processed datasets saved successfully.")

if __name__ == "__main__":
    bbb, matches, comps, player_meta_df = load_and_preprocess_raw_data()
    save_processed_data(bbb, matches, comps, player_meta_df)
