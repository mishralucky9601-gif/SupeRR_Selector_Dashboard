"""
Page 1: Home / Overview View
SupeRR Selector Season 2 - Round 1
"""

import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from src.components import render_hero, render_stat_card, apply_plotly_theme
from src.config import COLOR_RR_PINK, COLOR_NAVY, COLOR_WHITE, COLOR_BG_LIGHT_BLUE, COLOR_ACCENT_GOLD

def render_home_page(deliveries_df, matches_df, comps_df, player_meta_df, bat_rankings, bowl_rankings):
    """Renders Page 1: Home / Overview."""
    # Hero Section
    st.markdown(render_hero(), unsafe_allow_html=True)

    # Top KPI Metrics Row
    total_matches = matches_df["match_id"].nunique()
    total_players = player_meta_df["player_id"].nunique()
    total_deliveries = len(deliveries_df)
    pressure_deliveries = deliveries_df["is_pressure"].sum()
    pressure_pct = (pressure_deliveries / total_deliveries) * 100.0

    top_batter = bat_rankings.iloc[0] if len(bat_rankings) > 0 else None
    top_bowler = bowl_rankings.iloc[0] if len(bowl_rankings) > 0 else None

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        st.markdown(
            render_stat_card("Matches Analysed", f"{total_matches:,}", "IPL & T20I (2022–2026)"),
            unsafe_allow_html=True
        )
    with c2:
        st.markdown(
            render_stat_card("Players Tracked", f"{total_players:,}", "Full Competition Dataset"),
            unsafe_allow_html=True
        )
    with c3:
        st.markdown(
            render_stat_card("Pressure Deliveries", f"{pressure_deliveries:,}", f"{pressure_pct:.1f}% of total balls"),
            unsafe_allow_html=True
        )
    with c4:
        b_name = top_batter["striker_name"] if top_batter is not None else "N/A"
        b_score = f"{top_batter['reliability_score']:.1f}" if top_batter is not None else "--"
        st.markdown(
            render_stat_card("Top Batter Under Pressure", b_name, f"Reliability Score: {b_score}/100"),
            unsafe_allow_html=True
        )
    with c5:
        bw_name = top_bowler["bowler_name"] if top_bowler is not None else "N/A"
        bw_score = f"{top_bowler['reliability_score']:.1f}" if top_bowler is not None else "--"
        st.markdown(
            render_stat_card("Top Bowler Under Pressure", bw_name, f"Reliability Score: {bw_score}/100"),
            unsafe_allow_html=True
        )

    st.markdown("<div style='height: 18px;'></div>", unsafe_allow_html=True)

    # Analytical Insights Highlight Section
    st.markdown("### 🔍 Key Analytical Findings")
    col_i1, col_i2, col_i3 = st.columns(3)
    with col_i1:
        st.markdown(f"""
        <div class="rr-card" style="border-left: 4px solid {COLOR_RR_PINK};">
            <h4 style="margin: 0 0 8px 0; font-size: 1.05rem; color: {COLOR_NAVY};">⚡ The Finisher Surge</h4>
            <p style="font-size: 0.88rem; color: #475569; line-height: 1.5; margin: 0;">
                High-pressure situations in T20 (RRR &ge; 9.5 and Death Overs 17–20) demand explosive boundary acceleration.
                Specialist middle-order pinch-hitters like <strong>Shashank Singh</strong> (SR 184.4), <strong>Ashutosh Sharma</strong> (SR 180.9), and <strong>Suryakumar Yadav</strong> (SR 185.9) significantly elevate their scoring rates beyond normal baseline levels.
            </p>
        </div>
        """, unsafe_allow_html=True)
    with col_i2:
        st.markdown(f"""
        <div class="rr-card" style="border-left: 4px solid #3B82F6;">
            <h4 style="margin: 0 0 8px 0; font-size: 1.05rem; color: {COLOR_NAVY};">🎯 Mystery Spin & Yorker Precision</h4>
            <p style="font-size: 0.88rem; color: #475569; line-height: 1.5; margin: 0;">
                Under acute pressure, defensive dot-ball percentage and yorker execution outweigh pure pace.
                Death specialists like <strong>Matheesha Pathirana</strong> (60 pressure wickets, 72% consistency) and deceptive spinners like <strong>Rashid Khan</strong> (79 pressure wickets) restrict scoring while consistently producing breakthrough wickets.
            </p>
        </div>
        """, unsafe_allow_html=True)
    with col_i3:
        st.markdown(fr"""
        <div class="rr-card" style="border-left: 4px solid {COLOR_ACCENT_GOLD};">
            <h4 style="margin: 0 0 8px 0; font-size: 1.05rem; color: {COLOR_NAVY};">⚖️ Baseline vs Clutch Divergence</h4>
            <p style="font-size: 0.88rem; color: #475569; line-height: 1.5; margin: 0;">
                The SupeRR model explicitly measures <em>Clutch Delta</em> ($\Delta SR, \Delta Econ$).
                Several players with solid career averages suffer an 18–25% dip under pressure, whereas genuine pressure performers increase boundary percentage by up to +6.8% and reduce dot-ball rates when matches hang in the balance.
            </p>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)

    # Charts Row: Pressure Deliveries Breakdown & Top 5 Preview
    ch_col1, ch_col2 = st.columns([1, 1])

    with ch_col1:
        st.markdown("#### 📊 Pressure Situations Distribution")
        pres_counts = deliveries_df[deliveries_df["is_pressure"]]["pressure_tag"].value_counts().reset_index()
        pres_counts.columns = ["Pressure Category", "Deliveries"]

        fig_pres = px.pie(
            pres_counts,
            values="Deliveries",
            names="Pressure Category",
            hole=0.45,
            color_discrete_sequence=[COLOR_RR_PINK, "#2563EB", "#0D9488", "#F59E0B", "#8B5CF6", "#EC4899", "#64748B"]
        )
        apply_plotly_theme(
            fig_pres,
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.35, xanchor="center", x=0.5),
            height=340
        )
        fig_pres.update_traces(textposition='inside', textinfo='percent+label')
        st.plotly_chart(fig_pres, use_container_width=True)

    with ch_col2:
        st.markdown("#### ⚡ Tournament Data Coverage by Format & Year")
        comp_summary = deliveries_df.groupby(["season", "match_format"]).size().reset_index(name="Balls")
        fig_comp = px.bar(
            comp_summary,
            x="season",
            y="Balls",
            color="match_format",
            barmode="group",
            color_discrete_map={"T20": COLOR_RR_PINK, "T20I": COLOR_NAVY},
            labels={"season": "Season", "Balls": "Deliveries Bowled", "match_format": "Format"}
        )
        apply_plotly_theme(
            fig_comp,
            height=340,
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        st.plotly_chart(fig_comp, use_container_width=True)

    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)

    # Top 5 Quick Preview Tables
    tab_b, tab_bw = st.tabs(["🏏 Top 5 Batters Under Pressure", "🎯 Top 5 Bowlers Under Pressure"])

    with tab_b:
        top5_b = bat_rankings.head(5)[[
            "rank", "striker_name", "role", "reliability_score", "runs_pres", "balls_pres", "sr_pres", "avg_pres", "delta_sr"
        ]].copy()
        top5_b.columns = ["Rank", "Batter", "Role", "Reliability Score", "Pressure Runs", "Pressure Balls", "Pressure SR", "Pressure Avg", "SR Delta (Δ)"]
        top5_b["Pressure SR"] = top5_b["Pressure SR"].map("{:.1f}".format)
        top5_b["Pressure Avg"] = top5_b["Pressure Avg"].map("{:.1f}".format)
        top5_b["SR Delta (Δ)"] = top5_b["SR Delta (Δ)"].map("{:+.1f}".format)
        st.dataframe(top5_b, use_container_width=True, hide_index=True)

    with tab_bw:
        top5_bw = bowl_rankings.head(5)[[
            "rank", "bowler_name", "role", "reliability_score", "wickets_pres", "legal_balls_pres", "econ_pres", "avg_pres", "delta_econ"
        ]].copy()
        top5_bw.columns = ["Rank", "Bowler", "Role", "Reliability Score", "Pressure Wickets", "Pressure Balls", "Pressure Econ", "Pressure Avg", "Econ Delta (Δ)"]
        top5_bw["Pressure Econ"] = top5_bw["Pressure Econ"].map("{:.2f}".format)
        top5_bw["Pressure Avg"] = top5_bw["Pressure Avg"].map("{:.1f}".format)
        top5_bw["Econ Delta (Δ)"] = top5_bw["Econ Delta (Δ)"].map("{:+.2f}".format)
        st.dataframe(top5_bw, use_container_width=True, hide_index=True)
