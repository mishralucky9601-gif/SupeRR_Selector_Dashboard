"""
Page 2: Batting Under Pressure View
SupeRR Selector Season 2 - Round 1
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from src.components import apply_plotly_theme, render_stat_card
from src.config import COLOR_RR_PINK, COLOR_NAVY, COLOR_WHITE, COLOR_BG_LIGHT_BLUE, COLOR_ACCENT_GOLD, COLOR_SUCCESS_GREEN

def render_batting_page(bat_rankings, deliveries_df):
    """Renders Page 2: Batting Under Pressure."""
    st.markdown("## 🏏 Batting Under Pressure Analysis")
    st.markdown(
        '<p class="page-subtitle">Deep-dive evaluation of batters when facing critical match contexts: run chases, escalating required run rates, death overs, and early collapse recovery.</p>',
        unsafe_allow_html=True
    )

    if len(bat_rankings) == 0:
        st.warning("No batters meet the current qualification thresholds. Try reducing the minimum balls filter in the sidebar.")
        return

    top10 = bat_rankings.head(10).copy()

    # Summary KPI row for Top 10 Batters
    avg_top10_sr = top10["sr_pres"].mean()
    avg_top10_runs = int(top10["runs_pres"].sum())
    avg_top10_delta_sr = top10["delta_sr"].mean()
    avg_top10_const = top10["consistency_rate"].mean()

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(render_stat_card("Top 10 Aggregate Pressure Runs", f"{avg_top10_runs:,}", "Total runs scored under pressure"), unsafe_allow_html=True)
    with c2:
        st.markdown(render_stat_card("Top 10 Mean Pressure SR", f"{avg_top10_sr:.1f}", "Balls scored per 100 deliveries"), unsafe_allow_html=True)
    with c3:
        st.markdown(render_stat_card("Mean Strike Rate Acceleration", f"{avg_top10_delta_sr:+.1f}", "Pressure SR vs Normal SR"), unsafe_allow_html=True)
    with c4:
        st.markdown(render_stat_card("Mean Match Consistency", f"{avg_top10_const:.1f}%", "Pressure impact match rate"), unsafe_allow_html=True)

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Leaderboard Table with Pressure Barometer & Responsive Container
    st.markdown("### 🏆 Top 10 Batters Under Pressure")

    top10_table = top10.copy()
    top10_table["pressure_barometer"] = top10_table["reliability_score"].round(1)

    disp_cols = [
        "rank", "striker_name", "role", "reliability_score", "pressure_barometer",
        "runs_pres", "balls_pres", "sr_pres", "avg_pres",
        "bdry_pct_pres", "dot_pct_pres", "delta_sr", "consistency_rate"
    ]
    t10_table = top10_table[disp_cols].copy()
    t10_table.columns = [
        "Rank", "Batter", "Role", "Reliability Score", "Pressure Barometer",
        "Pressure Runs", "Pressure Balls", "Pressure SR", "Pressure Avg",
        "Boundary %", "Dot Ball %", "SR Delta (Δ)", "Consistency Rate"
    ]
    t10_table["Pressure SR"] = t10_table["Pressure SR"].round(1)
    t10_table["Pressure Avg"] = t10_table["Pressure Avg"].round(1)
    t10_table["Boundary %"] = t10_table["Boundary %"].map("{:.1f}%".format)
    t10_table["Dot Ball %"] = t10_table["Dot Ball %"].map("{:.1f}%".format)
    t10_table["SR Delta (Δ)"] = t10_table["SR Delta (Δ)"].map("{:+.1f}".format)
    t10_table["Consistency Rate"] = t10_table["Consistency Rate"].map("{:.1f}%".format)

    # Leaderboard Table with Pressure Barometer & Standard Clean Scroll Container
    st.dataframe(
        t10_table,
        use_container_width=True,
        hide_index=True,
        height=440,
        column_config={
            "Rank": st.column_config.NumberColumn("Rank", width="small"),
            "Batter": st.column_config.TextColumn("Batter", width="medium"),
            "Role": st.column_config.TextColumn("Role", width="small"),
            "Reliability Score": st.column_config.NumberColumn("Reliability Score", format="%.2f", width="small"),
            "Pressure Barometer": st.column_config.ProgressColumn(
                "Pressure Barometer",
                help="Clutch Reliability Meter (0-100)",
                format="%.1f",
                min_value=0,
                max_value=100,
                width="medium"
            ),
            "Pressure Runs": st.column_config.NumberColumn("Runs", width="small"),
            "Pressure Balls": st.column_config.NumberColumn("Balls", width="small"),
            "Pressure SR": st.column_config.NumberColumn("SR", format="%.1f", width="small"),
            "Pressure Avg": st.column_config.NumberColumn("Avg", format="%.1f", width="small"),
            "Boundary %": st.column_config.TextColumn("Boundary %", width="small"),
            "Dot Ball %": st.column_config.TextColumn("Dot %", width="small"),
            "SR Delta (Δ)": st.column_config.TextColumn("Δ SR", width="small"),
            "Consistency Rate": st.column_config.TextColumn("Consistency", width="small"),
        }
    )

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Interactive Visualizations Row
    col_chart1, col_chart2 = st.columns(2)

    with col_chart1:
        st.markdown("#### ⚡ Normal vs Pressure Strike Rate Comparison")
        fig_sr = go.Figure()
        fig_sr.add_trace(go.Bar(
            y=top10["striker_name"],
            x=top10["sr_norm"],
            name="Normal Strike Rate",
            orientation='h',
            marker=dict(color="#94A3B8")
        ))
        fig_sr.add_trace(go.Bar(
            y=top10["striker_name"],
            x=top10["sr_pres"],
            name="Pressure Strike Rate",
            orientation='h',
            marker=dict(color=COLOR_RR_PINK)
        ))
        apply_plotly_theme(
            fig_sr,
            barmode='group',
            height=420,
            xaxis_title="Strike Rate",
            yaxis=dict(autorange="reversed"),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        st.plotly_chart(fig_sr, use_container_width=True)

    with col_chart2:
        st.markdown("#### 📈 Boundary % vs Dot Ball % (Pressure Efficiency)")
        fig_eff = px.scatter(
            top10,
            x="dot_pct_pres",
            y="bdry_pct_pres",
            size="runs_pres",
            color="reliability_score",
            text="striker_name",
            color_continuous_scale=[[0, "#3B82F6"], [0.5, "#F59E0B"], [1.0, COLOR_RR_PINK]],
            labels={
                "dot_pct_pres": "Dot Ball % (Lower is Better)",
                "bdry_pct_pres": "Boundary % (Higher is Better)",
                "reliability_score": "Reliability Score",
                "runs_pres": "Pressure Runs"
            }
        )
        fig_eff.update_traces(textposition='top center', marker=dict(line=dict(width=1, color=COLOR_NAVY)))
        apply_plotly_theme(
            fig_eff,
            height=420,
            xaxis=dict(autorange="reversed")
        )
        st.plotly_chart(fig_eff, use_container_width=True)

    st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)

    # Detailed Player Spotlight Inspector
    st.markdown("### 🔎 Individual Batter Deep Dive")
    selected_player = st.selectbox(
        "Select a batter to inspect delivery-level profile:",
        top10["striker_name"].tolist()
    )

    player_row = top10[top10["striker_name"] == selected_player].iloc[0]
    pid = player_row["striker_id"]

    # Delivery breakdown for this player
    p_balls = deliveries_df[deliveries_df["striker_id"] == pid]
    p_balls_pres = p_balls[p_balls["is_pressure"]]

    sp1, sp2, sp3, sp4 = st.columns(4)
    with sp1:
        st.metric("Total Pressure Balls", f"{int(player_row['balls_pres'])}")
    with sp2:
        st.metric("Pressure Average", f"{player_row['avg_pres']:.1f}", f"Δ {player_row['delta_avg']:+.1f} vs Normal")
    with sp3:
        st.metric("Pressure Strike Rate", f"{player_row['sr_pres']:.1f}", f"Δ {player_row['delta_sr']:+.1f} vs Normal")
    with sp4:
        st.metric("Impact Match Rate", f"{player_row['consistency_rate']:.1f}%", f"{int(player_row['impact_matches'])} of {int(player_row['pressure_matches'])} matches")

    # In-depth breakdown by phase
    if len(p_balls_pres) > 0:
        col_tag, col_stroke = st.columns(2)
        with col_tag:
            tag_summary = p_balls_pres.groupby("pressure_tag").agg(
                Runs=("runs", "sum"),
                Balls=("is_batter_ball", "sum")
            ).reset_index()
            tag_summary["SR"] = (tag_summary["Runs"] / tag_summary["Balls"].replace(0, 1) * 100).round(1)
            fig_tag = px.bar(
                tag_summary,
                x="Runs",
                y="pressure_tag",
                orientation='h',
                color="SR",
                color_continuous_scale="Purp",
                title=f"{selected_player}: Runs & SR across Pressure Situations"
            )
            apply_plotly_theme(fig_tag, height=260)
            st.plotly_chart(fig_tag, use_container_width=True)

        with col_stroke:
            stroke_summary = p_balls_pres.groupby("pace_or_spin").agg(
                Runs=("runs", "sum"),
                Balls=("is_batter_ball", "sum")
            ).reset_index()
            stroke_summary["SR"] = (stroke_summary["Runs"] / stroke_summary["Balls"].replace(0, 1) * 100).round(1)
            fig_spin = px.bar(
                stroke_summary,
                x="pace_or_spin",
                y="Runs",
                color="pace_or_spin",
                color_discrete_map={"Pace": COLOR_RR_PINK, "Spin": COLOR_NAVY},
                title=f"{selected_player}: Pressure Runs vs Pace vs Spin"
            )
            apply_plotly_theme(fig_spin, height=260, showlegend=False)
            st.plotly_chart(fig_spin, use_container_width=True)
