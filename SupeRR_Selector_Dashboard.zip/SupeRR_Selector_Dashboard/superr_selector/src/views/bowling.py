"""
Page 3: Bowling Under Pressure View
SupeRR Selector Season 2 - Round 1
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from src.components import apply_plotly_theme, render_stat_card
from src.config import COLOR_RR_PINK, COLOR_NAVY, COLOR_WHITE, COLOR_BG_LIGHT_BLUE, COLOR_ACCENT_GOLD, COLOR_SUCCESS_GREEN

def render_bowling_page(bowl_rankings, deliveries_df):
    """Renders Page 3: Bowling Under Pressure."""
    st.markdown("## 🎯 Bowling Under Pressure Analysis")
    st.markdown(
        '<p class="page-subtitle">Evaluating bowlers tasked with defending low totals, containing runaway run chases, producing clutch breakthrough wickets, and mastering the death overs (overs 16–20).</p>',
        unsafe_allow_html=True
    )

    if len(bowl_rankings) == 0:
        st.warning("No bowlers meet the current qualification thresholds. Try reducing the minimum balls filter in the sidebar.")
        return

    top10 = bowl_rankings.head(10).copy()

    # Summary KPI row for Top 10 Bowlers
    total_top10_wkts = int(top10["wickets_pres"].sum())
    mean_top10_econ = top10["econ_pres"].mean()
    mean_top10_dot = top10["dot_pct_pres"].mean()
    mean_top10_death_econ = top10["death_econ"].dropna().mean()

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(render_stat_card("Top 10 Pressure Wickets", f"{total_top10_wkts:,}", "Breakthrough wickets in crunch moments"), unsafe_allow_html=True)
    with c2:
        st.markdown(render_stat_card("Top 10 Mean Pressure Economy", f"{mean_top10_econ:.2f}", "Runs conceded per 6 legal balls"), unsafe_allow_html=True)
    with c3:
        st.markdown(render_stat_card("Mean Dot Ball Percentage", f"{mean_top10_dot:.1f}%", "Zero-run deliveries forced under pressure"), unsafe_allow_html=True)
    with c4:
        st.markdown(render_stat_card("Mean Death Overs Economy", f"{mean_top10_death_econ:.2f}", "Overs 16–20 under pressure"), unsafe_allow_html=True)

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Leaderboard Table with Pressure Barometer & Responsive Container
    st.markdown("### 🏆 Top 10 Bowlers Under Pressure")

    top10_table = top10.copy()
    top10_table["pressure_barometer"] = top10_table["reliability_score"].round(1)

    disp_cols = [
        "rank", "bowler_name", "role", "reliability_score", "pressure_barometer",
        "wickets_pres", "legal_balls_pres", "econ_pres", "avg_pres",
        "dot_pct_pres", "delta_econ", "death_econ", "consistency_rate"
    ]
    t10_table = top10_table[disp_cols].copy()
    t10_table.columns = [
        "Rank", "Bowler", "Role", "Reliability Score", "Pressure Barometer",
        "Pressure Wickets", "Pressure Balls", "Pressure Econ", "Pressure Avg",
        "Dot Ball %", "Econ Delta (Δ)", "Death Econ (16-20)", "Consistency Rate"
    ]

    t10_table["Pressure Econ"] = t10_table["Pressure Econ"].round(2)
    t10_table["Pressure Avg"] = t10_table["Pressure Avg"].round(1)
    t10_table["Dot Ball %"] = t10_table["Dot Ball %"].map("{:.1f}%".format)
    t10_table["Econ Delta (Δ)"] = t10_table["Econ Delta (Δ)"].map("{:+.2f}".format)
    t10_table["Death Econ (16-20)"] = t10_table["Death Econ (16-20)"].map(lambda x: f"{x:.2f}" if pd.notna(x) else "N/A")
    t10_table["Consistency Rate"] = t10_table["Consistency Rate"].map("{:.1f}%".format)

    # Leaderboard Table with Pressure Barometer & Standard Clean Scroll Container
    st.dataframe(
        t10_table,
        use_container_width=True,
        hide_index=True,
        height=440,
        column_config={
            "Rank": st.column_config.NumberColumn("Rank", width="small"),
            "Bowler": st.column_config.TextColumn("Bowler", width="medium"),
            "Role": st.column_config.TextColumn("Role", width="small"),
            "Reliability Score": st.column_config.NumberColumn("Reliability Score", format="%.2f", width="small"),
            "Pressure Barometer": st.column_config.ProgressColumn(
                "Pressure Barometer",
                help="Clutch Reliability Meter (0-100)",
                format="%.1f",
                min_value=0,
                max_value=100,
                width="medium"
            ),
            "Pressure Wickets": st.column_config.NumberColumn("Wickets", width="small"),
            "Pressure Balls": st.column_config.NumberColumn("Balls", width="small"),
            "Pressure Econ": st.column_config.NumberColumn("Econ", format="%.2f", width="small"),
            "Pressure Avg": st.column_config.NumberColumn("Avg", format="%.1f", width="small"),
            "Dot Ball %": st.column_config.TextColumn("Dot %", width="small"),
            "Econ Delta (Δ)": st.column_config.TextColumn("Δ Econ", width="small"),
            "Death Econ (16-20)": st.column_config.TextColumn("Death Econ", width="small"),
            "Consistency Rate": st.column_config.TextColumn("Consistency", width="small"),
        }
    )

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # Visualizations Row: Normal vs Pressure Economy & Death Effectiveness
    col_ch1, col_ch2 = st.columns(2)

    with col_ch1:
        st.markdown("#### 📉 Normal vs Pressure Economy Rate (Lower is Better)")
        fig_econ = go.Figure()
        fig_econ.add_trace(go.Bar(
            y=top10["bowler_name"],
            x=top10["econ_norm"],
            name="Normal Economy",
            orientation='h',
            marker=dict(color="#94A3B8")
        ))
        fig_econ.add_trace(go.Bar(
            y=top10["bowler_name"],
            x=top10["econ_pres"],
            name="Pressure Economy",
            orientation='h',
            marker=dict(color=COLOR_NAVY)
        ))
        apply_plotly_theme(
            fig_econ,
            barmode='group',
            height=420,
            xaxis_title="Economy Rate (Runs/Over)",
            yaxis=dict(autorange="reversed"),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        st.plotly_chart(fig_econ, use_container_width=True)

    with col_ch2:
        st.markdown("#### ⚡ Death Overs Economy vs Wicket-Taking Rate")
        valid_death = top10.dropna(subset=["death_econ"]).copy()
        fig_death = px.scatter(
            valid_death,
            x="death_econ",
            y="wickets_pres",
            size="legal_balls_pres",
            color="reliability_score",
            text="bowler_name",
            color_continuous_scale=[[0, "#3B82F6"], [0.5, "#F59E0B"], [1.0, COLOR_RR_PINK]],
            labels={
                "death_econ": "Death Overs Economy (Lower is Better)",
                "wickets_pres": "Total Pressure Wickets",
                "reliability_score": "Reliability Score",
                "legal_balls_pres": "Pressure Balls Bowled"
            }
        )
        fig_death.update_traces(textposition='top center', marker=dict(line=dict(width=1, color=COLOR_NAVY)))
        apply_plotly_theme(
            fig_death,
            height=420,
            xaxis=dict(autorange="reversed")
        )
        st.plotly_chart(fig_death, use_container_width=True)

    st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)

    # Detailed Bowler Spotlight Inspector
    st.markdown("### 🔎 Individual Bowler Deep Dive")
    selected_bowler = st.selectbox(
        "Select a bowler to inspect delivery-level profile:",
        top10["bowler_name"].tolist()
    )

    bowler_row = top10[top10["bowler_name"] == selected_bowler].iloc[0]
    bid = bowler_row["bowler_id"]

    b_balls = deliveries_df[deliveries_df["bowler_id"] == bid]
    b_balls_pres = b_balls[b_balls["is_pressure"]]

    bp1, bp2, bp3, bp4 = st.columns(4)
    with bp1:
        st.metric("Pressure Balls Bowled", f"{int(bowler_row['legal_balls_pres'])}")
    with bp2:
        st.metric("Pressure Economy", f"{bowler_row['econ_pres']:.2f}", f"Δ {bowler_row['delta_econ']:+.2f} vs Normal")
    with bp3:
        st.metric("Pressure Wickets", f"{int(bowler_row['wickets_pres'])}", f"Avg: {bowler_row['avg_pres']:.1f}")
    with bp4:
        death_ec_txt = f"{bowler_row['death_econ']:.2f}" if pd.notna(bowler_row['death_econ']) else "N/A"
        st.metric("Death Overs Economy", death_ec_txt, f"{int(bowler_row['death_wkts']) if pd.notna(bowler_row['death_wkts']) else 0} death wkts")

    # In-depth breakdown by phase
    if len(b_balls_pres) > 0:
        col_bw1, col_bw2 = st.columns(2)
        with col_bw1:
            tag_b_summary = b_balls_pres.groupby("pressure_tag").agg(
                Runs=("bowler_runs_conceded", "sum"),
                Balls=("is_legal", "sum"),
                Wickets=("is_bowler_wicket", "sum")
            ).reset_index()
            tag_b_summary["Econ"] = (tag_b_summary["Runs"] / (tag_b_summary["Balls"] / 6.0).replace(0, 1)).round(2)
            fig_tag_b = px.bar(
                tag_b_summary,
                x="Wickets",
                y="pressure_tag",
                orientation='h',
                color="Econ",
                color_continuous_scale="Viridis_r",
                title=f"{selected_bowler}: Wickets & Econ across Pressure Situations"
            )
            apply_plotly_theme(fig_tag_b, height=260)
            st.plotly_chart(fig_tag_b, use_container_width=True)

        with col_bw2:
            dismissal_types = b_balls_pres[b_balls_pres["is_bowler_wicket"]]["dismissal_type"].value_counts().reset_index()
            dismissal_types.columns = ["Dismissal Type", "Count"]
            fig_w_type = px.pie(
                dismissal_types,
                values="Count",
                names="Dismissal Type",
                title=f"{selected_bowler}: Pressure Dismissal Modes",
                color_discrete_sequence=[COLOR_RR_PINK, COLOR_NAVY, "#10B981", "#F59E0B"]
            )
            apply_plotly_theme(fig_w_type, height=260)
            st.plotly_chart(fig_w_type, use_container_width=True)
