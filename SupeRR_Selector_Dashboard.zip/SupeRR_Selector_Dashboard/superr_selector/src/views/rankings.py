"""
Page 5: Final Rankings View
SupeRR Selector Season 2 - Round 1
"""

import streamlit as st
import pandas as pd
from src.components import render_stat_card
from src.config import COLOR_RR_PINK, COLOR_NAVY, COLOR_WHITE, COLOR_ACCENT_GOLD

def render_rankings_page(bat_rankings, bowl_rankings):
    """Renders Page 5: Official Final Rankings for Unstop Submission."""
    st.markdown("## 🏅 Official Final Player Rankings")
    st.markdown("""
    <p class="page-subtitle">
    Two separate, ordered Top-10 lists of the most reliable batters and bowlers under pressure in accordance with
    <strong>SupeRR Selector Season 2 Round 1</strong> requirements. Use these ranked lists to select players in rank order (1 to 10)
    in the Unstop competition submission dropdowns.
    </p>
    """, unsafe_allow_html=True)

    top10_bat = bat_rankings.head(10).copy()
    top10_bowl = bowl_rankings.head(10).copy()

    tab1, tab2 = st.tabs(["🏏 Top 10 Batters Under Pressure", "🎯 Top 10 Bowlers Under Pressure"])

    with tab1:
        st.markdown("### Top 10 Batters Under Pressure (Official Submission Order)")
        st.caption("Ordered strictly from Rank 1 (Highest Rated) to Rank 10 based on the Batting Reliability Score (BRS).")

        top10_bat_table = top10_bat.copy()
        top10_bat_table["pressure_barometer"] = top10_bat_table["reliability_score"].round(1)

        bat_display = top10_bat_table[[
            "rank", "striker_name", "role", "reliability_score", "pressure_barometer",
            "runs_pres", "balls_pres", "sr_pres", "avg_pres",
            "bdry_pct_pres", "dot_pct_pres", "delta_sr", "consistency_rate"
        ]].copy()

        bat_display.columns = [
            "Rank", "Player Name", "Role", "Reliability Score", "Pressure Barometer",
            "Pressure Runs", "Pressure Balls", "Pressure SR", "Pressure Avg",
            "Boundary %", "Dot Ball %", "SR Delta (Δ)", "Consistency Rate"
        ]

        # Format numeric display
        bat_display["Pressure SR"] = bat_display["Pressure SR"].round(1)
        bat_display["Pressure Avg"] = bat_display["Pressure Avg"].round(1)
        bat_display["Boundary %"] = bat_display["Boundary %"].map("{:.1f}%".format)
        bat_display["Dot Ball %"] = bat_display["Dot Ball %"].map("{:.1f}%".format)
        bat_display["SR Delta (Δ)"] = bat_display["SR Delta (Δ)"].map("{:+.1f}".format)
        bat_display["Consistency Rate"] = bat_display["Consistency Rate"].map("{:.1f}%".format)

        # Standard Clean Scrollable Table
        st.dataframe(
            bat_display,
            use_container_width=True,
            hide_index=True,
            height=440,
            column_config={
                "Rank": st.column_config.NumberColumn("Rank", width="small"),
                "Player Name": st.column_config.TextColumn("Player", width="medium"),
                "Role": st.column_config.TextColumn("Role", width="small"),
                "Reliability Score": st.column_config.NumberColumn("Reliability Score", format="%.2f", width="small"),
                "Pressure Barometer": st.column_config.ProgressColumn(
                    "Pressure Barometer",
                    help="BRS Reliability Index (0-100)",
                    format="%.1f",
                    min_value=0,
                    max_value=100,
                    width="medium"
                ),
                "Pressure Runs": st.column_config.NumberColumn("Runs", width="small"),
                "Pressure Balls": st.column_config.NumberColumn("Balls", width="small"),
                "Pressure SR": st.column_config.NumberColumn("SR", format="%.1f", width="small"),
                "Pressure Avg": st.column_config.NumberColumn("Avg", format="%.1f", width="small"),
                "Boundary %": st.column_config.TextColumn("Boundary %", width="small"),
                "Dot Ball %": st.column_config.TextColumn("Dot %", width="small"),
                "SR Delta (Δ)": st.column_config.TextColumn("Δ SR", width="small"),
                "Consistency Rate": st.column_config.TextColumn("Consistency", width="small"),
            }
        )

        # CSV Download Button
        csv_bat = top10_bat[[
            "rank", "striker_id", "striker_name", "role", "reliability_score",
            "runs_pres", "balls_pres", "sr_pres", "avg_pres", "delta_sr", "consistency_rate"
        ]].to_csv(index=False).encode('utf-8')

        st.download_button(
            label="📥 Download Top 10 Batters CSV (Unstop Submission Ready)",
            data=csv_bat,
            file_name="SupeRR_Selector_Top10_Batters.csv",
            mime="text/csv",
            help="Download the verified Top 10 Batters dataset for competition verification."
        )

        st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
        st.markdown("#### 💡 Batting Rankings Rationale Summary")
        for _, r in top10_bat.iterrows():
            st.markdown(f"""
            - **Rank {int(r['rank'])}: {r['striker_name']}** ({r['role']}) — **BRS: {r['reliability_score']:.1f}/100**  
              *Key Stats:* {int(r['runs_pres'])} runs off {int(r['balls_pres'])} balls under pressure | SR: **{r['sr_pres']:.1f}** ({r['delta_sr']:+.1f} vs normal) | Avg: **{r['avg_pres']:.1f}** | Consistency: **{r['consistency_rate']:.1f}%**.
            """)

    with tab2:
        st.markdown("### Top 10 Bowlers Under Pressure (Official Submission Order)")
        st.caption("Ordered strictly from Rank 1 (Highest Rated) to Rank 10 based on the Bowling Reliability Score (BowRS).")

        top10_bowl_table = top10_bowl.copy()
        top10_bowl_table["pressure_barometer"] = top10_bowl_table["reliability_score"].round(1)

        bowl_display = top10_bowl_table[[
            "rank", "bowler_name", "role", "reliability_score", "pressure_barometer",
            "wickets_pres", "legal_balls_pres", "econ_pres", "avg_pres",
            "dot_pct_pres", "delta_econ", "death_econ", "consistency_rate"
        ]].copy()

        bowl_display.columns = [
            "Rank", "Player Name", "Role", "Reliability Score", "Pressure Barometer",
            "Pressure Wickets", "Pressure Balls", "Pressure Econ", "Pressure Avg",
            "Dot Ball %", "Econ Delta (Δ)", "Death Econ", "Consistency Rate"
        ]

        bowl_display["Pressure Econ"] = bowl_display["Pressure Econ"].round(2)
        bowl_display["Pressure Avg"] = bowl_display["Pressure Avg"].round(1)
        bowl_display["Dot Ball %"] = bowl_display["Dot Ball %"].map("{:.1f}%".format)
        bowl_display["Econ Delta (Δ)"] = bowl_display["Econ Delta (Δ)"].map("{:+.2f}".format)
        bowl_display["Death Econ"] = bowl_display["Death Econ"].map(lambda x: f"{x:.2f}" if pd.notna(x) else "N/A")
        bowl_display["Consistency Rate"] = bowl_display["Consistency Rate"].map("{:.1f}%".format)

        # Standard Clean Scrollable Table
        st.dataframe(
            bowl_display,
            use_container_width=True,
            hide_index=True,
            height=440,
            column_config={
                "Rank": st.column_config.NumberColumn("Rank", width="small"),
                "Player Name": st.column_config.TextColumn("Player", width="medium"),
                "Role": st.column_config.TextColumn("Role", width="small"),
                "Reliability Score": st.column_config.NumberColumn("Reliability Score", format="%.2f", width="small"),
                "Pressure Barometer": st.column_config.ProgressColumn(
                    "Pressure Barometer",
                    help="BowRS Reliability Index (0-100)",
                    format="%.1f",
                    min_value=0,
                    max_value=100,
                    width="medium"
                ),
                "Pressure Wickets": st.column_config.NumberColumn("Wickets", width="small"),
                "Pressure Balls": st.column_config.NumberColumn("Balls", width="small"),
                "Pressure Econ": st.column_config.NumberColumn("Econ", format="%.2f", width="small"),
                "Pressure Avg": st.column_config.NumberColumn("Avg", format="%.1f", width="small"),
                "Dot Ball %": st.column_config.TextColumn("Dot %", width="small"),
                "Econ Delta (Δ)": st.column_config.TextColumn("Δ Econ", width="small"),
                "Death Econ": st.column_config.TextColumn("Death Econ", width="small"),
                "Consistency Rate": st.column_config.TextColumn("Consistency", width="small"),
            }
        )

        csv_bowl = top10_bowl[[
            "rank", "bowler_id", "bowler_name", "role", "reliability_score",
            "wickets_pres", "legal_balls_pres", "econ_pres", "avg_pres", "delta_econ", "consistency_rate"
        ]].to_csv(index=False).encode('utf-8')

        st.download_button(
            label="📥 Download Top 10 Bowlers CSV (Unstop Submission Ready)",
            data=csv_bowl,
            file_name="SupeRR_Selector_Top10_Bowlers.csv",
            mime="text/csv",
            help="Download the verified Top 10 Bowlers dataset for competition verification."
        )

        st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
        st.markdown("#### 💡 Bowling Rankings Rationale Summary")
        for _, r in top10_bowl.iterrows():
            d_ec = f"{r['death_econ']:.2f}" if pd.notna(r['death_econ']) else "N/A"
            st.markdown(f"""
            - **Rank {int(r['rank'])}: {r['bowler_name']}** ({r['role']}) — **BowRS: {r['reliability_score']:.1f}/100**  
              *Key Stats:* {int(r['wickets_pres'])} wickets in {int(r['legal_balls_pres'])} legal pressure deliveries | Econ: **{r['econ_pres']:.2f}** ({r['delta_econ']:+.2f} run containment) | Death Econ: **{d_ec}** | Consistency: **{r['consistency_rate']:.1f}%**.
            """)
