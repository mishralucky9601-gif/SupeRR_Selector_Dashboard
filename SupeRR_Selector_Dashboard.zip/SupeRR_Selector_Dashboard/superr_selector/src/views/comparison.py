"""
Page 4: Player Head-to-Head Comparison View
SupeRR Selector Season 2 - Round 1
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from src.components import apply_plotly_theme, get_plotly_theme
from src.config import COLOR_RR_PINK, COLOR_NAVY, COLOR_WHITE, COLOR_BG_LIGHT_BLUE, COLOR_ACCENT_GOLD, COLOR_SUCCESS_GREEN

def render_comparison_page(bat_rankings, bowl_rankings, deliveries_df):
    """Renders Page 4: Player Head-to-Head Comparison."""
    st.markdown("## ⚔️ Head-to-Head Player Comparison")
    st.markdown(
        '<p class="page-subtitle">Compare 2 to 4 players side-by-side across pressure metrics, normal baselines, consistency, and sample size volume.</p>',
        unsafe_allow_html=True
    )

    comp_type = st.radio("Choose comparison category:", ["Batters", "Bowlers"], horizontal=True)

    if comp_type == "Batters":
        df_pool = bat_rankings
        name_col = "striker_name"
        default_options = df_pool[name_col].head(3).tolist() if len(df_pool) >= 3 else df_pool[name_col].tolist()
        player_choices = st.multiselect(
            "Select 2 to 4 batters to compare:",
            options=df_pool[name_col].tolist(),
            default=default_options,
            max_selections=4
        )
    else:
        df_pool = bowl_rankings
        name_col = "bowler_name"
        default_options = df_pool[name_col].head(3).tolist() if len(df_pool) >= 3 else df_pool[name_col].tolist()
        player_choices = st.multiselect(
            "Select 2 to 4 bowlers to compare:",
            options=df_pool[name_col].tolist(),
            default=default_options,
            max_selections=4
        )

    if len(player_choices) < 2:
        st.info("Please select at least 2 players from the dropdown above to generate comparison charts and side-by-side analytics.")
        return

    comp_df = df_pool[df_pool[name_col].isin(player_choices)].copy()

    # 1. Side-by-Side Key Metrics Table
    st.markdown("### 📋 Comparative Scorecard")
    if comp_type == "Batters":
        display_df = comp_df[[
            name_col, "role", "reliability_score", "runs_pres", "balls_pres",
            "sr_pres", "avg_pres", "bdry_pct_pres", "dot_pct_pres", "delta_sr", "consistency_rate"
        ]].copy()
        display_df.columns = [
            "Player", "Role", "Reliability Score", "Pressure Runs", "Pressure Balls",
            "Pressure SR", "Pressure Avg", "Boundary %", "Dot Ball %", "SR Delta (Δ)", "Consistency"
        ]
        display_df["Pressure SR"] = display_df["Pressure SR"].map("{:.1f}".format)
        display_df["Pressure Avg"] = display_df["Pressure Avg"].map("{:.1f}".format)
        display_df["Boundary %"] = display_df["Boundary %"].map("{:.1f}%".format)
        display_df["Dot Ball %"] = display_df["Dot Ball %"].map("{:.1f}%".format)
        display_df["SR Delta (Δ)"] = display_df["SR Delta (Δ)"].map("{:+.1f}".format)
        display_df["Consistency"] = display_df["Consistency"].map("{:.1f}%".format)
    else:
        display_df = comp_df[[
            name_col, "role", "reliability_score", "wickets_pres", "legal_balls_pres",
            "econ_pres", "avg_pres", "dot_pct_pres", "delta_econ", "death_econ", "consistency_rate"
        ]].copy()
        display_df.columns = [
            "Player", "Role", "Reliability Score", "Pressure Wickets", "Pressure Balls",
            "Pressure Econ", "Pressure Avg", "Dot Ball %", "Econ Delta (Δ)", "Death Econ", "Consistency"
        ]
        display_df["Pressure Econ"] = display_df["Pressure Econ"].map("{:.2f}".format)
        display_df["Pressure Avg"] = display_df["Pressure Avg"].map("{:.1f}".format)
        display_df["Dot Ball %"] = display_df["Dot Ball %"].map("{:.1f}%".format)
        display_df["Econ Delta (Δ)"] = display_df["Econ Delta (Δ)"].map("{:+.2f}".format)
        display_df["Death Econ"] = display_df["Death Econ"].map(lambda x: f"{x:.2f}" if pd.notna(x) else "N/A")
        display_df["Consistency"] = display_df["Consistency"].map("{:.1f}%".format)

    st.dataframe(display_df, use_container_width=True, hide_index=True)

    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)

    # 2. Radar / Spider Chart Comparison (Normalized Dimensions 0-100)
    col_rad, col_bar = st.columns([1, 1])

    palette = [COLOR_RR_PINK, "#2563EB", "#059669", "#D97706"]

    with col_rad:
        st.markdown("#### 🕸️ Multi-Dimensional Attribute Radar")
        fig_radar = go.Figure()

        if comp_type == "Batters":
            categories = ["Scoring Velocity (SR)", "Survivability (Avg)", "Boundary Dominance", "Dot Ball Control", "Clutch Delta (ΔSR)", "Match Consistency"]
            for idx, (_, row) in enumerate(comp_df.iterrows()):
                # Normalize metrics onto 0-100 scale for radar visualization
                val_sr = min(100, max(20, (row["sr_pres"] - 110) / (210 - 110) * 100))
                val_avg = min(100, max(20, (row["avg_pres"] - 15) / (60 - 15) * 100))
                val_bdry = min(100, max(20, (row["bdry_pct_pres"] - 10) / (35 - 10) * 100))
                val_dot = min(100, max(20, (50 - row["dot_pct_pres"]) / (50 - 20) * 100))
                val_delta = min(100, max(20, (row["delta_sr"] + 15) / (85 + 15) * 100))
                val_const = min(100, max(20, row["consistency_rate"]))

                values = [val_sr, val_avg, val_bdry, val_dot, val_delta, val_const]
                values.append(values[0]) # close polygon

                fig_radar.add_trace(go.Scatterpolar(
                    r=values,
                    theta=categories + [categories[0]],
                    fill='toself',
                    name=row[name_col],
                    line=dict(color=palette[idx % len(palette)], width=2),
                    opacity=0.65
                ))
        else:
            categories = ["Economy Containment", "Wicket Frequency", "Dot Suppression", "Clutch Delta (ΔEcon)", "Death Overs Mastery", "Match Consistency"]
            for idx, (_, row) in enumerate(comp_df.iterrows()):
                val_econ = min(100, max(20, (12 - row["econ_pres"]) / (12 - 6) * 100))
                val_wkt = min(100, max(20, ((row["wickets_pres"] / max(1, row["legal_balls_pres"])) * 100 - 2) / (12 - 2) * 100))
                val_dot = min(100, max(20, (row["dot_pct_pres"] - 25) / (55 - 25) * 100))
                val_delta = min(100, max(20, (row["delta_econ"] + 2) / (3 + 2) * 100))
                death_ec = row["death_econ"] if pd.notna(row["death_econ"]) else row["econ_pres"]
                val_death = min(100, max(20, (13 - death_ec) / (13 - 7) * 100))
                val_const = min(100, max(20, row["consistency_rate"]))

                values = [val_econ, val_wkt, val_dot, val_delta, val_death, val_const]
                values.append(values[0])

                fig_radar.add_trace(go.Scatterpolar(
                    r=values,
                    theta=categories + [categories[0]],
                    fill='toself',
                    name=row[name_col],
                    line=dict(color=palette[idx % len(palette)], width=2),
                    opacity=0.65
                ))

        apply_plotly_theme(
            fig_radar,
            polar=dict(
                radialaxis=dict(visible=True, range=[0, 100], showticklabels=False),
                bgcolor="rgba(255, 255, 255, 0.7)"
            ),
            height=400,
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.25, xanchor="center", x=0.5)
        )
        st.plotly_chart(fig_radar, use_container_width=True)

    with col_bar:
        st.markdown("#### 📊 Sample Size & Exposure Volume")
        if comp_type == "Batters":
            fig_vol = go.Figure()
            fig_vol.add_trace(go.Bar(
                x=comp_df[name_col],
                y=comp_df["balls_norm"],
                name="Normal Balls Faced",
                marker_color="#94A3B8"
            ))
            fig_vol.add_trace(go.Bar(
                x=comp_df[name_col],
                y=comp_df["balls_pres"],
                name="Pressure Balls Faced",
                marker_color=COLOR_RR_PINK
            ))
            apply_plotly_theme(
                fig_vol,
                barmode='stack',
                height=400,
                yaxis_title="Deliveries Faced",
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            st.plotly_chart(fig_vol, use_container_width=True)
        else:
            fig_vol = go.Figure()
            fig_vol.add_trace(go.Bar(
                x=comp_df[name_col],
                y=comp_df["legal_balls_norm"],
                name="Normal Balls Bowled",
                marker_color="#94A3B8"
            ))
            fig_vol.add_trace(go.Bar(
                x=comp_df[name_col],
                y=comp_df["legal_balls_pres"],
                name="Pressure Balls Bowled",
                marker_color=COLOR_NAVY
            ))
            apply_plotly_theme(
                fig_vol,
                barmode='stack',
                height=400,
                yaxis_title="Legal Deliveries Bowled",
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            st.plotly_chart(fig_vol, use_container_width=True)

    st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)

    # 3. Strengths & Weaknesses Analysis Cards
    st.markdown("### 🔍 Tactical Scout Report & Verdict")
    scout_cols = st.columns(len(comp_df))

    for idx, (_, p_row) in enumerate(comp_df.iterrows()):
        with scout_cols[idx]:
            p_name = p_row[name_col]
            p_score = p_row["reliability_score"]
            p_role = p_row["role"]

            if comp_type == "Batters":
                str1 = f"⚡ Pressure SR: <strong>{p_row['sr_pres']:.1f}</strong> (Δ {p_row['delta_sr']:+.1f})"
                str2 = f"🎯 Boundary Rate: <strong>{p_row['bdry_pct_pres']:.1f}%</strong>"
                str3 = f"🛡️ Pressure Avg: <strong>{p_row['avg_pres']:.1f}</strong>"
                weak1 = f"Dot ball rate under pressure: <strong>{p_row['dot_pct_pres']:.1f}%</strong>"
                weak2 = f"Total pressure sample: <strong>{int(p_row['balls_pres'])} balls</strong>"
            else:
                str1 = f"🔒 Pressure Econ: <strong>{p_row['econ_pres']:.2f}</strong> (Δ {p_row['delta_econ']:+.2f})"
                str2 = f"🎯 Wickets Under Pressure: <strong>{int(p_row['wickets_pres'])} wkts</strong>"
                str3 = f"🛡️ Dot Ball %: <strong>{p_row['dot_pct_pres']:.1f}%</strong>"
                d_econ_t = f"{p_row['death_econ']:.2f}" if pd.notna(p_row['death_econ']) else "N/A"
                weak1 = f"Death overs (16–20) economy: <strong>{d_econ_t}</strong>"
                weak2 = f"Total pressure legal balls: <strong>{int(p_row['legal_balls_pres'])} balls</strong>"

            st.markdown(f"""
            <div class="rr-card" style="border-top: 4px solid {palette[idx % len(palette)]}; height: 100%;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                    <span style="font-size: 0.75rem; font-weight: 700; color: #64748B;">{p_role}</span>
                    <span style="background: {COLOR_NAVY}; color: #FFFFFF; font-size: 0.75rem; font-weight: 800; padding: 2px 8px; border-radius: 6px;">
                        Score: {p_score:.1f}
                    </span>
                </div>
                <h4 style="margin: 0 0 12px 0; font-size: 1.15rem; color: {COLOR_NAVY};">{p_name}</h4>
                <div style="font-size: 0.82rem; margin-bottom: 8px;">
                    <strong style="color: {COLOR_SUCCESS_GREEN};">✅ Key Strengths:</strong>
                    <ul style="margin: 4px 0 8px 16px; padding: 0;">
                        <li>{str1}</li>
                        <li>{str2}</li>
                        <li>{str3}</li>
                    </ul>
                </div>
                <div style="font-size: 0.82rem;">
                    <strong style="color: #E11D48;">⚠️ Scout Flags / Nuance:</strong>
                    <ul style="margin: 4px 0 0 16px; padding: 0;">
                        <li>{weak1}</li>
                        <li>{weak2}</li>
                    </ul>
                </div>
            </div>
            """, unsafe_allow_html=True)
