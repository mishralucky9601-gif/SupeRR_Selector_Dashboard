"""
Page 6: Methodology View
SupeRR Selector Season 2 - Round 1
"""

import streamlit as st
from src.config import (
    COLOR_RR_PINK,
    COLOR_NAVY,
    BATTING_MIN_PRESSURE_BALLS,
    BATTING_MIN_TOTAL_BALLS,
    BOWLING_MIN_PRESSURE_BALLS,
    BOWLING_MIN_TOTAL_BALLS,
    BAYES_PRIOR_BALLS_BAT,
    BAYES_PRIOR_BALLS_BOWL
)

def render_methodology_page():
    """Renders Page 6: Complete Methodology, Math Formulations, and Assumptions."""
    st.markdown("## 📐 Analytics Methodology & Model Architecture")
    st.markdown("""
    <p class="page-subtitle">
    This document describes the complete mathematical, statistical, and domain formulation for <strong>SupeRR Selector Season 2 (Round 1)</strong>.
    Our approach strictly adheres to sound cricket principles: no arbitrary ratings, no fabricated metrics, and transparent reproducibility.
    </p>
    """, unsafe_allow_html=True)

    # Section 1: Pressure Definition
    st.markdown("### 1. Match-Context Pressure Definition")
    st.markdown("""
    Pressure in T20 cricket is dynamic, non-linear, and asymmetric between Innings 1 (Target Setting) and Innings 2 (The Chase).
    We define pressure at the **individual delivery level** using live reconstructed match states:
    """)

    st.markdown("""
    #### 🏏 Innings 2: Run Chase Mechanics
    During the chase, pressure is mathematically anchored to the **Required Run Rate ($RRR$)**, remaining legal balls ($B_{rem}$), and wickets in hand ($W_{hand}$):
    """)
    st.latex(r"RRR_t = \frac{\max(0, \text{Target} - \text{Runs}_t) \times 6}{\max(1, 120 - \text{BallsBowled}_t)}")

    st.markdown(r"""
    A delivery in Innings 2 is tagged as **Pressure** if any of the following contextual triggers are satisfied:
    1. **Steep Required Run Rate ($RRR \ge 9.5$)**: In the second half of the chase ($B_{rem} \le 60$ balls remaining).
    2. **Extreme Pressure Crunch ($RRR \ge 11.0$)**: At any stage after the Powerplay ($\text{BallsBowled} > 36$).
    3. **Death Overs Chase Finish**: Overs 16–20 ($\text{Over} \ge 16$) with contest actively alive ($\text{RunsNeeded} > 0$ and $RRR \le 24.0$).
    4. **Top-Order Chase Collapse**: Powerplay with 3+ wickets lost ($\text{BallsBowled} \le 36 \land \text{WicketsLost} \ge 3$).
    5. **Lower-Order Crisis**: 6+ wickets lost ($\text{WicketsLost} \ge 6$) with $>15$ runs still required.
    6. **Knockout Stage Leverage**: In playoffs/finals ($\text{Knockout} = 1$), over $\ge 14$ and $RRR \ge 8.5$.
    """)

    st.markdown(r"""
    #### 🛡️ Innings 1: Target Setting Mechanics
    In the first innings, before a target exists, pressure stems from **structural collapse** or **death-overs acceleration**:
    1. **Powerplay Collapse**: 3+ wickets lost in the first 6 overs ($\text{BallsBowled} \le 36 \land \text{WicketsLost} \ge 3$).
    2. **Middle-Overs Collapse**: 4+ wickets lost inside 10 overs ($\text{BallsBowled} \le 60 \land \text{WicketsLost} \ge 4$).
    3. **Death Overs Finishing**: Overs 17 to 20 ($\text{Over} \ge 17$), where maximum scoring velocity is required.
    4. **Knockout Match Crunch**: In playoffs/finals, over $\ge 15$ with 3+ wickets lost.
    """)

    st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)

    # Section 2: Data Cleaning & Delivery Validation
    st.markdown("### 2. Data Processing & Scoring Rule Validation")
    st.markdown("""
    The dataset consists of 200,999 delivery records across 883 matches (IPL and T20Is from 2022 to 2026).
    The following data integrity rules were strictly enforced:
    - **Legal Deliveries**: Balls where `extras_type` is not in `['wide', 'Overstep', 'other']`. Wides and no-balls are re-bowled and do not increment legal over counts.
    - **Batter Balls Faced**: Deliveries where `extras_type != 'wide'`. No-balls (foot-fault `Overstep` and waist-high `other`) count as balls faced by the striker.
    - **Bowler Runs Conceded**: Striker runs off the bat + wide runs (`extras1_runs`) + no-ball penalties (`extras1_runs`). Byes and leg-byes are team extras and are never charged to the bowler.
    - **Bowler Wickets**: Strictly dismissals credited to the bowler (`Caught`, `Bowled`, `LBW`, `Stump`, `Hit Wicket`). Run-outs and retirements are excluded from bowler credits.
    """)

    st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)

    # Section 3: Mathematical Scoring Models
    st.markdown("### 3. Reliability Scoring Models (BRS & BowRS)")
    st.markdown("""
    To eliminate subjective bias, player ratings are computed using **multi-factor standardized Z-scores** augmented with **Empirical Bayes sample shrinkage**:
    """)

    st.markdown("#### 🏏 Batting Reliability Score (BRS)")
    st.markdown(r"""
    The BRS comprises four defensible analytical components:
    1. **Pressure Performance ($S_{perf}, 45\%$)**: Strike Rate, Runs Per Dismissal (Average), Boundary Ball %, and Dot Ball Containment under pressure.
    2. **Clutch Delta ($S_{delta}, 30\%$)**: Differential between pressure performance and normal baseline ($\Delta SR = SR_{pres} - SR_{norm}$, $\Delta Avg$, $\Delta Dot\%$).
    3. **Match Consistency ($S_{const}, 25\%$)**: Percentage of matches under pressure where player achieved an impactful contribution ($Runs \ge 20$ or $SR \ge 140$).
    4. **Empirical Bayes Credibility Weight ($w_{cred}$)**: Downweights small sample volatility using prior $N_0 = 100$ balls:
    """)
    st.latex(r"w_{cred} = \frac{N_{pres}}{N_{pres} + N_0}")
    st.latex(r"\text{Raw BRS} = w_{cred} \times \left( 0.45 \cdot S_{perf} + 0.30 \cdot S_{delta} + 0.25 \cdot S_{const} \right)")

    st.markdown("#### 🎯 Bowling Reliability Score (BowRS)")
    st.markdown(r"""
    The BowRS evaluates a bowler's capacity to contain runs and deliver breakthroughs under duress:
    1. **Pressure Performance ($S_{perf}, 45\%$)**: Economy Rate (inverted), Wicket-Taking Rate ($Wkts / Balls$), Dot Ball %, and Boundary Concession suppression.
    2. **Clutch Delta ($S_{delta}, 30\%$)**: Economy suppression ($\Delta Econ = Econ_{norm} - Econ_{pres}$) and Dot Ball elevation ($\Delta Dot\%$).
    3. **Match Consistency & Death Overs ($S_{const}, 25\%$)**: Proportion of matches maintaining $\le 8.0$ economy or taking wickets under pressure, plus Overs 16–20 effectiveness.
    4. **Bayesian Shrinkage Weight ($w_{cred}$)** with prior $B_0 = 100$ legal balls:
    """)
    st.latex(r"w_{cred} = \frac{B_{pres}}{B_{pres} + B_0}")
    st.latex(r"\text{Raw BowRS} = w_{cred} \times \left( 0.45 \cdot S_{perf} + 0.30 \cdot S_{delta} + 0.25 \cdot S_{const} \right)")

    st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)

    # Section 4: Eligibility & Sample Size Thresholds
    st.markdown("### 4. Eligibility & Sample-Size Thresholds")
    st.markdown(f"""
    To ensure statistical significance and prevent skewed single-innings outliers:
    - **Batters**: Minimum **{BATTING_MIN_PRESSURE_BALLS} balls faced under pressure** AND **{BATTING_MIN_TOTAL_BALLS} total career balls faced**.
    - **Bowlers**: Minimum **{BOWLING_MIN_PRESSURE_BALLS} legal deliveries bowled under pressure** AND **{BOWLING_MIN_TOTAL_BALLS} total career legal balls**.
    - Users can interactively modify this threshold in the sidebar slider to explore deeper pools or tighter elite championship filters.
    """)

    st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)

    # Section 5: Limitations and Edge Cases
    st.markdown("### 5. Limitations & Assumptions")
    st.markdown("""
    1. **Pitch and Venue Normalization**: Stadium dimensions and pitch degradation (e.g. Wankhede vs Chepauk) influence baseline run rates. While format and season normalization are applied, individual venue par scores could be incorporated in future iterations.
    2. **DLS Revisions**: Matches with rain interruptions use revised targets from `matches.csv`; incomplete matches without official revised targets calculate RRR against prorated quotas.
    3. **Opposition Quality**: All deliveries within top-tier competitions (IPL and full-member T20Is) are treated with equal competitive weight.
    """)
