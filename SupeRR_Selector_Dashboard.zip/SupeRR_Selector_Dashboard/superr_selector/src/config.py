"""
Configuration and styling constants for SupeRR Selector Season 2 Dashboard.
Theme: Rajasthan Royals Official Visual Identity
"""

# Brand Colors (RR Palette)
COLOR_BG_LIGHT_PINK = "#FCE4EF"
COLOR_BG_LIGHT_BLUE = "#DCEEFF"
COLOR_RR_PINK = "#E0228F"
COLOR_RR_DARK_PINK = "#B3146E"
COLOR_NAVY = "#182B49"
COLOR_NAVY_LIGHT = "#243D66"
COLOR_WHITE = "#FFFFFF"
COLOR_CARD_BG = "rgba(255, 255, 255, 0.95)"
COLOR_ACCENT_GOLD = "#F5A623"
COLOR_SUCCESS_GREEN = "#10B981"
COLOR_DANGER_RED = "#EF4444"
COLOR_BORDER = "rgba(224, 34, 143, 0.15)"
COLOR_BORDER_SUBTLE = "rgba(24, 43, 73, 0.10)"

# Scoring Model Hyperparameters
BATTING_MIN_PRESSURE_BALLS = 100
BATTING_MIN_TOTAL_BALLS = 250
BOWLING_MIN_PRESSURE_BALLS = 100
BOWLING_MIN_TOTAL_BALLS = 250

# Bayesian Shrinkage Half-Weights
BAYES_PRIOR_BALLS_BAT = 100.0
BAYES_PRIOR_BALLS_BOWL = 100.0

import os

# Project Paths dynamically resolved relative to the package root
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_RAW_DIR = os.path.join(BASE_DIR, "Data Pack")
DATA_PROCESSED_DIR = os.path.join(BASE_DIR, "data")
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
LOGO_SVG_PATH = os.path.join(ASSETS_DIR, "rajasthan_royals_logo.svg")
