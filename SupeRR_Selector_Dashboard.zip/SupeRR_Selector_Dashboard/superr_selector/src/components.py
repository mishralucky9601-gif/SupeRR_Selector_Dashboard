"""
UI Components, Custom CSS, Hero Section, and Chart Themes for SupeRR Selector.
Theme: Official Rajasthan Royals Visual Identity (Pastel Pink + Sky Blue + Dark Navy)
"""

import base64
import os
import plotly.graph_objects as go
import plotly.express as px
from src.config import (
    COLOR_BG_LIGHT_PINK,
    COLOR_BG_LIGHT_BLUE,
    COLOR_RR_PINK,
    COLOR_RR_DARK_PINK,
    COLOR_NAVY,
    COLOR_NAVY_LIGHT,
    COLOR_WHITE,
    COLOR_CARD_BG,
    COLOR_BORDER,
    COLOR_BORDER_SUBTLE,
    COLOR_ACCENT_GOLD,
    COLOR_SUCCESS_GREEN,
    LOGO_SVG_PATH
)

def get_base64_logo():
    """Reads the official Rajasthan Royals logo SVG and returns base64 data URI."""
    if os.path.exists(LOGO_SVG_PATH):
        with open(LOGO_SVG_PATH, "rb") as f:
            encoded = base64.b64encode(f.read()).decode("utf-8")
        return f"data:image/svg+xml;base64,{encoded}"
    return ""

def get_custom_css():
    """Generates the master CSS stylesheet for the dashboard."""
    logo_uri = get_base64_logo()
    return f"""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Cinzel:wght@600;700;800;900&display=swap');

    /* Global reset and typography */
    html, body, [class*="css"], [data-testid="stAppViewContainer"] {{
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        color: #0F172A;
    }}

    /* Main background gradient: Soft Pastel Pink to Sky Blue with subtle RR watermark */
    .stApp, [data-testid="stAppViewContainer"], .stMain {{
        background: linear-gradient(135deg, {COLOR_BG_LIGHT_PINK} 0%, #FFFFFF 45%, {COLOR_BG_LIGHT_BLUE} 100%) !important;
        background-attachment: fixed !important;
        position: relative;
    }}

    header[data-testid="stHeader"] {{
        background: transparent !important;
    }}

    /* Page background subtle watermark */
    .stApp::before {{
        content: "";
        position: fixed;
        bottom: 5%;
        right: 3%;
        width: 380px;
        height: 380px;
        background-image: url("{logo_uri}");
        background-repeat: no-repeat;
        background-position: center;
        background-size: contain;
        opacity: 0.04;
        pointer-events: none;
        z-index: 0;
    }}

    /* Top padding removal and content elevation above watermark */
    .block-container {{
        position: relative !important;
        z-index: 1 !important;
        padding-top: 1.2rem !important;
        padding-bottom: 3rem !important;
        max-width: 1320px !important;
    }}

    /* ========================================================
       1. SIDEBAR STYLING & HIGH-CONTRAST NAVIGATION FIX
       ======================================================== */
    [data-testid="stSidebar"], [data-testid="stSidebarContent"] {{
        background: linear-gradient(180deg, #FFFFFF 0%, #FFF5F9 50%, {COLOR_BG_LIGHT_PINK} 100%) !important;
        border-right: 1px solid rgba(224, 34, 143, 0.18) !important;
        box-shadow: 2px 0 16px rgba(24, 43, 73, 0.04);
    }}

    /* Sidebar Headings & Captions */
    [data-testid="stSidebar"] h1,
    [data-testid="stSidebar"] h2,
    [data-testid="stSidebar"] h3 {{
        color: #0F172A !important;
        font-family: 'Outfit', sans-serif !important;
        font-size: 1.05rem !important;
        font-weight: 700 !important;
        margin-top: 8px !important;
        margin-bottom: 8px !important;
        letter-spacing: -0.01em;
    }}

    [data-testid="stSidebar"] p,
    [data-testid="stSidebar"] span,
    [data-testid="stSidebar"] label {{
        color: #1E293B !important;
        font-weight: 600 !important;
    }}

    /* Sidebar Navigation Radio Container */
    [data-testid="stSidebar"] [data-testid="stRadio"] {{
        width: 100% !important;
    }}

    [data-testid="stSidebar"] [data-testid="stRadio"] > div {{
        gap: 6px !important;
        display: flex !important;
        flex-direction: column !important;
    }}

    /* Sidebar Navigation Item Labels */
    [data-testid="stSidebar"] [data-testid="stRadio"] label {{
        background: #FFFFFF !important;
        border: 1px solid rgba(24, 43, 73, 0.12) !important;
        border-radius: 12px !important;
        padding: 9px 14px !important;
        margin-bottom: 2px !important;
        display: flex !important;
        align-items: center !important;
        gap: 12px !important;
        cursor: pointer !important;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03) !important;
    }}

    /* Text inside navigation labels - Dark, crisp and high-contrast */
    [data-testid="stSidebar"] [data-testid="stRadio"] label p,
    [data-testid="stSidebar"] [data-testid="stRadio"] label span,
    [data-testid="stSidebar"] [data-testid="stRadio"] label div {{
        color: #0F172A !important; /* Deep Dark Charcoal/Navy - Never White! */
        font-family: 'Outfit', sans-serif !important;
        font-size: 0.94rem !important;
        font-weight: 650 !important;
        line-height: 1.3 !important;
        margin: 0 !important;
    }}

    /* Hover state for navigation items */
    [data-testid="stSidebar"] [data-testid="stRadio"] label:hover {{
        background: #FCE7F3 !important; /* Soft Rose Pink */
        border-color: #E0228F !important;
        transform: translateX(4px) !important;
        box-shadow: 0 3px 10px rgba(224, 34, 143, 0.15) !important;
    }}

    [data-testid="stSidebar"] [data-testid="stRadio"] label:hover p,
    [data-testid="stSidebar"] [data-testid="stRadio"] label:hover span {{
        color: #700836 !important; /* Deep Maroon on hover */
    }}

    /* Selected / Active state */
    [data-testid="stSidebar"] [data-testid="stRadio"] label:has(input:checked) {{
        background: linear-gradient(135deg, #E0228F 0%, #BE185D 100%) !important;
        border-color: #9D174D !important;
        box-shadow: 0 4px 14px rgba(224, 34, 143, 0.35) !important;
        transform: translateX(2px) !important;
    }}

    [data-testid="stSidebar"] [data-testid="stRadio"] label:has(input:checked) p,
    [data-testid="stSidebar"] [data-testid="stRadio"] label:has(input:checked) span,
    [data-testid="stSidebar"] [data-testid="stRadio"] label:has(input:checked) div {{
        color: #FFFFFF !important; /* Crisp pure white against the active magenta pill */
        font-weight: 700 !important;
    }}

    /* Custom Radio Dot Styling */
    [data-testid="stSidebar"] [data-testid="stRadio"] input[type="radio"] {{
        accent-color: #E0228F !important;
        width: 16px !important;
        height: 16px !important;
        margin-right: 2px !important;
    }}

    /* ========================================================
       2. HEADER SUBTITLE CONTRAST & TYPOGRAPHY
       ======================================================== */
    h1, h2, h3, h4, h5, h6 {{
        font-family: 'Outfit', sans-serif !important;
        font-weight: 700 !important;
        color: #0F172A !important;
        letter-spacing: -0.02em;
    }}

    /* High-contrast subtitle style right below page headings */
    .page-subtitle {{
        font-size: 1.0rem !important;
        color: #334155 !important; /* Solid, crisp slate gray with strong contrast */
        font-weight: 500 !important;
        line-height: 1.6 !important;
        margin-top: -6px !important;
        margin-bottom: 22px !important;
    }}

    /* Default markdown paragraphs contrast */
    .stMarkdown p {{
        color: #1E293B;
        line-height: 1.55;
    }}

    /* ========================================================
       3. OFFICIAL RAJASTHAN ROYALS LIGHT HERO BANNER
       ======================================================== */
    .rr-hero-card {{
        background: linear-gradient(135deg, #FFFFFF 0%, #FFF7FA 50%, #FDEBF4 100%) !important;
        border: 1px solid rgba(224, 34, 143, 0.22) !important;
        border-radius: 24px !important;
        padding: 34px 42px !important;
        margin-bottom: 24px !important;
        box-shadow: 0 10px 30px rgba(224, 34, 143, 0.08), 0 2px 10px rgba(24, 43, 73, 0.03) !important;
        position: relative !important;
        overflow: hidden !important;
        display: flex !important;
        justify-content: space-between !important;
        align-items: center !important;
    }}

    /* Central/Right subtle Rajasthan Royals Crest Watermark */
    .rr-hero-watermark {{
        position: absolute !important;
        right: 20%;
        top: 50%;
        transform: translateY(-50%);
        width: 320px;
        height: 320px;
        background-image: url("{logo_uri}");
        background-repeat: no-repeat;
        background-position: center;
        background-size: contain;
        opacity: 0.12;
        pointer-events: none;
        z-index: 1;
    }}

    .rr-hero-content {{
        position: relative !important;
        z-index: 2 !important;
        max-width: 680px !important;
    }}

    .rr-hero-badge {{
        display: inline-flex !important;
        align-items: center !important;
        gap: 6px !important;
        padding: 5px 14px !important;
        background: linear-gradient(90deg, #E0228F 0%, #BE185D 100%) !important;
        color: #FFFFFF !important;
        font-weight: 800 !important;
        font-size: 0.74rem !important;
        letter-spacing: 0.08em !important;
        text-transform: uppercase !important;
        border-radius: 999px !important;
        box-shadow: 0 3px 10px rgba(224, 34, 143, 0.28) !important;
        margin-bottom: 12px !important;
    }}

    .rr-hero-title {{
        font-family: 'Outfit', sans-serif !important;
        font-size: 2.85rem !important;
        font-weight: 900 !important;
        line-height: 1.15 !important;
        color: #E0228F !important;
        margin: 0 0 8px 0 !important;
        letter-spacing: -0.02em !important;
    }}

    .rr-hero-tagline {{
        font-family: 'Outfit', sans-serif !important;
        font-size: 1.15rem !important;
        font-weight: 700 !important;
        color: #182B49 !important;
        margin-bottom: 8px !important;
        letter-spacing: -0.01em !important;
    }}

    .rr-hero-desc {{
        font-size: 0.90rem !important;
        color: #475569 !important;
        line-height: 1.55 !important;
        margin-bottom: 20px !important;
        max-width: 620px !important;
        font-weight: 500 !important;
    }}

    .rr-hero-actions {{
        display: flex !important;
        align-items: center !important;
        gap: 12px !important;
        flex-wrap: wrap !important;
    }}

    .rr-hero-btn-outline {{
        display: inline-flex !important;
        align-items: center !important;
        gap: 8px !important;
        padding: 8px 18px !important;
        background: #FFFFFF !important;
        border: 1.5px solid #E0228F !important;
        color: #E0228F !important;
        font-weight: 700 !important;
        font-size: 0.85rem !important;
        border-radius: 999px !important;
        box-shadow: 0 2px 8px rgba(224, 34, 143, 0.10) !important;
        transition: all 0.2s ease !important;
    }}
    .rr-hero-btn-outline:hover {{
        background: #FCE7F3 !important;
        transform: translateY(-2px) !important;
    }}

    .rr-hero-btn-solid {{
        display: inline-flex !important;
        align-items: center !important;
        gap: 8px !important;
        padding: 8px 20px !important;
        background: linear-gradient(135deg, #E0228F 0%, #BE185D 100%) !important;
        border: 1.5px solid #E0228F !important;
        color: #FFFFFF !important;
        font-weight: 700 !important;
        font-size: 0.85rem !important;
        border-radius: 999px !important;
        box-shadow: 0 4px 14px rgba(224, 34, 143, 0.35) !important;
        transition: all 0.2s ease !important;
    }}
    .rr-hero-btn-solid:hover {{
        background: #BE185D !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 18px rgba(224, 34, 143, 0.5) !important;
    }}

    .rr-hero-badge-meta {{
        display: inline-flex !important;
        align-items: center !important;
        gap: 6px !important;
        padding: 8px 16px !important;
        background: rgba(255, 255, 255, 0.90) !important;
        border: 1px solid rgba(24, 43, 73, 0.12) !important;
        color: #475569 !important;
        font-size: 0.82rem !important;
        font-weight: 600 !important;
        border-radius: 999px !important;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02) !important;
    }}

    /* Right side white logo square card */
    .rr-hero-logo-card {{
        position: relative !important;
        z-index: 2 !important;
        background: #FFFFFF !important;
        border: 1px solid rgba(224, 34, 143, 0.20) !important;
        border-radius: 22px !important;
        width: 135px !important;
        height: 135px !important;
        min-width: 135px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        padding: 16px !important;
        box-shadow: 0 10px 25px rgba(224, 34, 143, 0.12), 0 2px 6px rgba(24, 43, 73, 0.04) !important;
        transition: transform 0.3s ease, box-shadow 0.3s ease !important;
    }}
    .rr-hero-logo-card:hover {{
        transform: translateY(-3px) scale(1.02) !important;
        box-shadow: 0 14px 32px rgba(224, 34, 143, 0.18) !important;
    }}

    .rr-hero-logo-img {{
        width: 100% !important;
        height: 100% !important;
        object-fit: contain !important;
    }}

    /* ========================================================
       4. STANDARD CLEAN TABLE STYLING (NO CONFLICTING SCROLLBARS)
       ======================================================== */
    [data-testid="stDataFrame"] {{
        width: 100% !important;
        min-width: 100% !important;
        border: 1px solid rgba(24, 43, 73, 0.12) !important;
        border-radius: 14px !important;
        box-shadow: 0 4px 16px rgba(24, 43, 73, 0.04) !important;
        background: #FFFFFF !important;
        overflow: hidden !important; /* Prevents outer double scrollbars */
        margin-bottom: 20px !important;
    }}

    [data-testid="stDataFrame"] > div {{
        border-radius: 14px !important;
        overflow: hidden !important; /* Prevents nested duplicate scrollbars */
    }}

    /* Clean custom scrollbar for Glide Data Grid */
    [data-testid="stDataFrame"] ::-webkit-scrollbar {{
        width: 8px !important;
        height: 8px !important;
    }}

    [data-testid="stDataFrame"] ::-webkit-scrollbar-track {{
        background: #F8FAFC !important;
        border-radius: 8px !important;
    }}

    [data-testid="stDataFrame"] ::-webkit-scrollbar-thumb {{
        background: #CBD5E1 !important;
        border-radius: 8px !important;
    }}

    [data-testid="stDataFrame"] ::-webkit-scrollbar-thumb:hover {{
        background: {COLOR_RR_PINK} !important;
    }}

    /* ========================================================
       5. ERROR BOX STYLING, CONTRAST & LEFT-ALIGNMENT
       ======================================================== */
    [data-testid="stException"], .stException {{
        background-color: #1e1e1e !important;
        border: 1px solid #334155 !important;
        border-left: 6px solid #EF4444 !important;
        border-radius: 12px !important;
        padding: 16px 20px !important;
        margin: 12px 0 24px 0 !important;
        text-align: left !important;
        width: 100% !important;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35) !important;
        color: #F8FAFC !important;
    }}

    [data-testid="stException"] pre, 
    [data-testid="stException"] code,
    .stException pre,
    .stException code {{
        background-color: #141414 !important;
        color: #F1F5F9 !important;
        font-family: 'Consolas', 'Fira Code', 'Courier New', monospace !important;
        font-size: 0.88rem !important;
        line-height: 1.6 !important;
        text-align: left !important;
        white-space: pre-wrap !important;
        word-break: break-word !important;
        padding: 12px !important;
        border-radius: 8px !important;
        border: 1px solid #27272A !important;
    }}

    /* Bright syntax highlighting for traceback readability */
    [data-testid="stException"] .token.keyword, [data-testid="stException"] .keyword {{
        color: #FB7185 !important;
        font-weight: 700;
    }}
    [data-testid="stException"] .token.string, [data-testid="stException"] .string {{
        color: #34D399 !important;
    }}
    [data-testid="stException"] .token.function, [data-testid="stException"] .function {{
        color: #38BDF8 !important;
    }}
    [data-testid="stException"] .token.number, [data-testid="stException"] .number {{
        color: #FBBF24 !important;
    }}

    /* Enforce strict left-alignment on error container */
    div:has(> [data-testid="stException"]) {{
        display: flex !important;
        justify-content: flex-start !important;
        align-items: flex-start !important;
        width: 100% !important;
        text-align: left !important;
    }}

    /* KPI / Stat Metric Cards - Clean, Uniform Royal Navy Typography */
    .rr-stat-card {{
        background: #FFFFFF;
        border: 1px solid rgba(24, 43, 73, 0.08);
        border-radius: 16px;
        padding: 18px 20px;
        box-shadow: 0 4px 18px rgba(24, 43, 73, 0.04);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }}
    .rr-stat-card:hover {{
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(224, 34, 143, 0.12);
        border-color: rgba(224, 34, 143, 0.3);
    }}
    .rr-stat-label {{
        font-size: 0.78rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        color: #64748B;
        margin-bottom: 6px;
        line-height: 1.3;
    }}
    .rr-stat-value {{
        font-family: 'Outfit', sans-serif !important;
        font-size: 1.85rem;
        font-weight: 800 !important;
        color: #182B49 !important; /* Standard clean uniform color across all metric cards */
        line-height: 1.25 !important;
        margin-bottom: 4px !important;
        letter-spacing: -0.01em;
        word-break: normal;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }}
    .rr-stat-highlight {{
        color: #182B49 !important; /* Uniform Royal Navy - no inconsistent pink values */
    }}
    .rr-stat-sub {{
        font-size: 0.78rem;
        color: #64748B;
        display: flex;
        align-items: center;
        gap: 4px;
        line-height: 1.3;
    }}

    /* Data Cards */
    .rr-card {{
        background: #FFFFFF;
        border: 1px solid rgba(24, 43, 73, 0.08);
        border-radius: 16px;
        padding: 22px 24px;
        margin-bottom: 20px;
        box-shadow: 0 4px 18px rgba(24, 43, 73, 0.04);
    }}

    /* Streamlit Tabs */
    .stTabs [data-baseweb="tab-list"] {{
        gap: 8px;
        background-color: rgba(255, 255, 255, 0.85);
        padding: 6px 8px;
        border-radius: 14px;
        border: 1px solid rgba(224, 34, 143, 0.15);
    }}
    .stTabs [data-baseweb="tab"] {{
        border-radius: 10px;
        font-family: 'Outfit', sans-serif;
        font-weight: 600;
        font-size: 0.95rem;
        color: #0F172A;
        padding: 10px 18px;
    }}
    .stTabs [aria-selected="true"] {{
        background-color: {COLOR_RR_PINK} !important;
        color: #FFFFFF !important;
        box-shadow: 0 4px 14px rgba(224, 34, 143, 0.35);
    }}

    /* Mobile adjustments */
    @media (max-width: 768px) {{
        .rr-hero-card {{
            padding: 26px 20px !important;
        }}
        .rr-hero-bg-logo {{
            width: 200px;
            height: 200px;
            opacity: 0.50;
            right: 0;
            top: 60%;
        }}
        .rr-title-cinematic {{
            font-size: 2.1rem !important;
        }}
        .rr-hero-actions {{
            flex-direction: column;
            align-items: stretch;
        }}
    }}
    </style>
    """

def render_hero():
    """Renders the official Rajasthan Royals hero banner with clean pastel aesthetic matching the reference photo."""
    logo_uri = get_base64_logo()
    return f"""
    <div class="rr-hero-card">
        <div class="rr-hero-watermark"></div>
        <div class="rr-hero-content">
            <div class="rr-hero-badge">★ OFFICIAL RAJASTHAN ROYALS ANALYTICS</div>
            <h1 class="rr-hero-title">SupeRR Selector</h1>
            <div class="rr-hero-tagline">Clutch • Composure • Royal Resilience</div>
            <div class="rr-hero-desc">
                Official algorithmic evaluation of player reliability under intense match pressure. Defending totals, death overs execution, required run rate accelerations, and collapse recoveries.
            </div>
            <div class="rr-hero-actions">
                <span class="rr-hero-btn-outline">🏏 Top 10 Batters</span>
                <span class="rr-hero-btn-solid">🎯 Top 10 Bowlers</span>
                <span class="rr-hero-badge-meta">⚡ 883 Matches • 200,999 Balls Analyzed</span>
            </div>
        </div>
        <div class="rr-hero-logo-card">
            <img src="{logo_uri}" class="rr-hero-logo-img" alt="Rajasthan Royals" />
        </div>
    </div>
    """

def render_stat_card(label, value, subtext="", is_highlight=False, suffix=""):
    """Renders a KPI card with uniform clean typography and responsive text scaling for names."""
    val_str = str(value)
    # Check if value is a long player name/text to prevent awkward line wrapping
    is_text = not val_str.replace(",", "").replace(".", "").replace("+", "").replace("-", "").replace("%", "").isdigit()
    size_style = "font-size: 1.35rem;" if (is_text and len(val_str) > 10) else ""
    return f"""
    <div class="rr-stat-card">
        <div class="rr-stat-label">{label}</div>
        <div class="rr-stat-value" style="{size_style}" title="{value}{suffix}">{value}{suffix}</div>
        <div class="rr-stat-sub">{subtext}</div>
    </div>
    """

def get_plotly_theme(**kwargs):
    """Returns standard Plotly layout configuration matching the RR pastel theme with safe overrides."""
    base_theme = {
        "font": dict(family="Plus Jakarta Sans, sans-serif", color=COLOR_NAVY, size=12),
        "paper_bgcolor": "rgba(0,0,0,0)",
        "plot_bgcolor": "rgba(255, 255, 255, 0.8)",
        "margin": dict(l=40, r=30, t=50, b=40),
        "xaxis": dict(
            gridcolor="rgba(24, 43, 73, 0.08)",
            linecolor="rgba(24, 43, 73, 0.2)",
            tickfont=dict(color=COLOR_NAVY, size=11),
            title_font=dict(color=COLOR_NAVY, size=12, family="Outfit, sans-serif")
        ),
        "yaxis": dict(
            gridcolor="rgba(24, 43, 73, 0.08)",
            linecolor="rgba(24, 43, 73, 0.2)",
            tickfont=dict(color=COLOR_NAVY, size=11),
            title_font=dict(color=COLOR_NAVY, size=12, family="Outfit, sans-serif")
        ),
        "legend": dict(
            bgcolor="rgba(255, 255, 255, 0.9)",
            bordercolor="rgba(24, 43, 73, 0.1)",
            borderwidth=1,
            font=dict(size=11, color=COLOR_NAVY)
        )
    }
    for k, v in kwargs.items():
        if k in base_theme and isinstance(base_theme[k], dict) and isinstance(v, dict):
            base_theme[k] = {**base_theme[k], **v}
        else:
            base_theme[k] = v
    return base_theme

def apply_plotly_theme(fig, **kwargs):
    """Safely applies the standard Rajasthan Royals theme to a Plotly figure without keyword argument collisions."""
    theme = get_plotly_theme(**kwargs)
    fig.update_layout(**theme)
    return fig
