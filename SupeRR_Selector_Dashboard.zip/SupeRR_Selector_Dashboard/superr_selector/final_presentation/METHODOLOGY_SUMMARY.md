# SupeRR Selector Season 2 | Round 1
## Executive Methodology Summary: Identifying the Most Reliable Players Under Pressure

**Presentation Deliverable:** `final_presentation/Rajasthan_Royals_SupeRR_Selector_Presentation.pptx`  
**Official Scope:** IPL & T20I Matches (2022–2026)  
**Deliveries Analyzed:** 194,014 official deliveries across 853 matches (371 IPL, 482 T20I)  
**Pressure Deliveries Tagged:** 64,029 (33.0% of official balls bowled)  
**Tracked Players:** 958 unique players  

---

### 1. Analytical Philosophy: The Pressure Imperative

Standard cricket statistics (such as career batting averages, overall strike rates, and raw bowling economies) fail to measure match-winning dependability because they aggregate unpressurized, low-leverage "garbage time" (e.g., chasing 20 off 30 balls with 8 wickets in hand) with high-stakes crisis situations (e.g., needing 45 off 18 balls). This methodology formulates an objective, delivery-level algorithmic framework that isolates high-pressure game states, benchmarks individual performance against unpressurized baselines, and shrinks small-sample outliers using Empirical Bayesian modeling.

---

### 2. Objective Pressure Classification Engine

Pressure in T20 cricket is structurally asymmetric between Innings 1 (Target Setting) and Innings 2 (The Chase). Every delivery is tagged dynamically:

#### Innings 1 (Target Setting - Resource Scarcity & Death Overs)
- **Powerplay Collapse:** $\le 36$ balls bowled AND $\ge 3$ wickets lost.
- **Middle-Overs Crisis:** $\le 60$ balls bowled AND $\ge 4$ wickets lost.
- **Deep Collapse:** $\le 84$ balls bowled AND $\ge 5$ wickets lost.
- **Death Overs Finishing:** Overs 17–20 (Balls 97–120) — every ball has maximum par score leverage.
- **Knockout Match Leverage:** Over $\ge 15$ with $\ge 3$ wickets lost in tournament playoffs/finals.

#### Innings 2 (The Chase - Dynamic Required Run Rate)
Live Required Run Rate ($RRR$) is reconstructed at every delivery:
$$RRR_t = \frac{\max(0, \text{Target} - \text{Runs}_t) \times 6}{\max(1, 120 - \text{BallsBowled}_t)}$$

- **Steep Chase:** $RRR \ge 9.5$ in the second half of the chase ($\le 60$ balls remaining).
- **Extreme Escalation:** $RRR \ge 11.0$ post-powerplay ($>36$ balls bowled).
- **Death Finish Pressure:** Overs 16–20 where $RRR \ge 8.0$ OR $\ge 5$ wickets down OR $>20$ runs needed.
- **Top-Order Collapse:** Powerplay with $\ge 3$ wickets lost, or lower-order crisis ($\ge 6$ wickets down).

#### Statistical Noise Exclusions
- **Walkovers Filtered:** Chases requiring $RRR \le 4.5$ with $\ge 7$ wickets in hand are tagged as unpressurized baselines.
- **Lost Causes Filtered:** Chases requiring $RRR > 36.0$ (e.g., 50 off 6 balls) are removed from pressure calculations to prevent statistical distortion.

---

### 3. Multi-Factor Scoring Models

#### Batting Reliability Score (BRS)
1. **Pressure Output Index (45%):**
   - Strike Rate under pressure ($35\%$)
   - Smoothed Runs Per Dismissal [$RPD = \frac{Runs}{Outs + 1}$] ($30\%$)
   - Boundary Ball % ($20\%$)
   - Dot Ball Avoidance [$100 - Dot\%$] ($15\%$)
2. **Clutch Differential Index (30%):**
   - $\Delta SR = SR_{pres} - SR_{norm}$ ($50\%$)
   - $\Delta Dot\% = Dot\%_{norm} - Dot\%_{pres}$ ($30\%$)
   - $\Delta RPD = RPD_{pres} - RPD_{norm}$ ($20\%$)
3. **Match Consistency Rate (25%):**
   - Percentage of pressure matches with impact score ($\ge 20$ runs OR $\ge 8$ balls faced at $SR \ge 140$).

#### Bowling Reliability Score (BowRS)
1. **Pressure Output Index (45%):**
   - Economy Rate suppression [$Z_{econ}$ inverted] ($35\%$)
   - Breakthrough Wicket-Taking Rate [$Wkts / LegalBalls$] ($30\%$)
   - Dot Ball % under pressure ($20\%$)
   - Boundary Concession Avoidance [$100 - Bdry\%$] ($15\%$)
2. **Clutch Differential Index (30%):**
   - $\Delta Econ = Econ_{norm} - Econ_{pres}$ ($50\%$)
   - $\Delta Dot\% = Dot\%_{pres} - Dot\%_{norm}$ ($30\%$)
   - $\Delta WktRate = WktRate_{pres} - WktRate_{norm}$ ($20\%$)
3. **Match Consistency Rate (25%):**
   - Percentage of pressure matches with impact bowling ($\ge 2$ wickets OR $Econ \le 7.00$).

#### Sample Credibility & Empirical Bayes Shrinkage
- **Eligibility Gates:** Minimum 100 pressure balls faced/bowled AND minimum 250 total career balls.
- **Bayesian Shrinkage:**
  $$w = \frac{N}{N + K} \quad (K = 100 \text{ prior balls})$$
  $$\text{Shrunk Score} = w \cdot \text{Raw Composite} + (1 - w) \cdot \text{Population Mean}$$
- **Final Scaling:** Min-Max normalized to $0 - 100$, anchoring the #1 ranked player at exactly 100.0.

---

### 4. Official Top 10 Rankings

#### Top 10 Batters Under Pressure
| Rank | Player Name | Role | BRS Score | Pressure Runs | Pressure Balls | Pressure SR | Pressure Avg | $\Delta$SR Lift | Consistency |
| :---: | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **1** | **Shashank Singh** | Middle-Order Batter | **100.0** | 682 | 384 | 177.6 | 62.0 | +50.9 | 45.2% |
| **2** | **Babar Azam** | Top-Order Batter | **99.03** | 302 | 160 | 188.8 | 50.3 | +64.3 | 58.3% |
| **3** | **Naman Dhir** | Top-Order Batter | **97.02** | 479 | 235 | 203.8 | 31.9 | +58.5 | 53.6% |
| **4** | **Suryakumar Yadav** | Top-Order Batter | **94.94** | 1,367 | 747 | 183.0 | 40.2 | +22.7 | 57.1% |
| **5** | **Tim David** | Middle-Order Batter | **92.97** | 1,399 | 747 | 187.3 | 37.8 | +24.7 | 51.4% |
| **6** | **Tristan Stubbs** | Middle-Order Batter | **91.44** | 1,090 | 659 | 165.4 | 38.9 | +39.6 | 49.1% |
| **7** | **Jos Buttler** | Top-Order Batter | **90.70** | 694 | 374 | 185.6 | 27.8 | +34.8 | 47.2% |
| **8** | **Shreyas Iyer** | Top-Order Batter | **90.36** | 852 | 473 | 180.1 | 29.4 | +36.2 | 51.2% |
| **9** | **Rinku Singh** | Middle-Order Batter | **90.07** | 1,291 | 769 | 167.9 | 38.0 | +37.8 | 49.3% |
| **10** | **Donovan Ferreira** | All-Rounder | **88.79** | 426 | 246 | 173.2 | 30.4 | +33.0 | 48.0% |

#### Top 10 Bowlers Under Pressure
| Rank | Bowler Name | Role | BowRS Score | Pressure Wkts | Legal Balls | Pressure Econ | Pressure Avg | $\Delta$Econ Supp. | Consistency |
| :---: | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **1** | **Sufiyan Muqeem** | Bowler (Spin) | **100.0** | 15 | 173 | 6.03 | 11.6 | +0.91 | 66.7% |
| **2** | **Abrar Ahmed** | Bowler (Spin) | **96.34** | 21 | 320 | 5.94 | 15.1 | +1.27 | 66.7% |
| **3** | **Sunil Narine** | All-Rounder (Spin) | **95.56** | 29 | 508 | 6.47 | 18.9 | +0.59 | 70.0% |
| **4** | **Mohammad Nawaz** | All-Rounder (Spin) | **95.08** | 24 | 258 | 6.07 | 10.9 | +1.42 | 50.0% |
| **5** | **Mitchell Santner** | All-Rounder (Spin) | **94.99** | 36 | 496 | 7.08 | 16.3 | +0.51 | 65.9% |
| **6** | **Rashid Khan** | Bowler (Spin) | **93.52** | 79 | 974 | 7.46 | 15.3 | -0.04 | 63.6% |
| **7** | **Hasan Mahmud** | Bowler (Pace) | **93.31** | 14 | 143 | 7.22 | 12.3 | +0.92 | 62.5% |
| **8** | **Matheesha Pathirana**| Bowler (Pace - Sling)| **91.82** | 54 | 601 | 8.98 | 16.6 | -0.31 | 75.6% |
| **9** | **Kuldeep Yadav** | Bowler (Spin) | **91.47** | 56 | 692 | 7.82 | 16.1 | +0.31 | 62.7% |
| **10** | **Sakib Hussain** | Bowler (Pace) | **91.08** | 11 | 136 | 8.56 | 17.6 | +1.94 | 80.0% |

---

### 5. Tactical Value for Rajasthan Royals & Decision Support

The outputs of this model provide direct operational decision support across four tactical pillars:
1. **In-Game Entry Point Optimization:** Transition from rigid pre-assigned batting orders to leverage-based entries. When Required Run Rate climbs above 10.5 in overs 13–16, promote high-delta finishers (Shashank Singh or Tim David archetypes) ahead of conventional accumulators to prevent run-rate paralysis.
2. **Defensive Over Allocation:** Exploit the "Spin Chokehold" by bowling mystery and finger spinners in overs 11–16, holding specialist sling-action fast bowlers (Matheesha Pathirana archetype) for high-stakes death overs 17 and 19.
3. **Matchup Matrix:** Pair high-delta batters against opposing bowler delivery profiles to exploit boundary release windows.
4. **Pressure-Simulated Net Scenarios:** Benchmark squad batters and bowlers in specific game states ($RRR \ge 11.0$, 5 wickets down, overs 16–20) to track decision-making latency and boundary execution under duress.

*Compliance Confirmation: Purely an analytical decision-support framework. In accordance with the organizer's explicit instructions, this submission contains zero auction valuation, retention, or player acquisition recommendations.*
