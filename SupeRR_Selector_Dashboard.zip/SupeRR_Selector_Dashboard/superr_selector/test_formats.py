import pandas as pd
import numpy as np

p = r'C:\Users\mishr\.gemini\antigravity\scratch\superr_selector\Data Pack'
bbb = pd.read_csv(f'{p}/ball_by_ball.csv')
matches = pd.read_csv(f'{p}/matches.csv')
comps = pd.read_csv(f'{p}/competitions.csv')

matches = matches.merge(comps[['comp_id', 'match_format', 'season', 'comp_name']], on='comp_id', how='left')
bbb = bbb.merge(matches[['match_id', 'match_format', 'season', 'comp_name', 'knock_out', 'revised_target']], on='match_id', how='left')

# Check distribution of balls by tournament format
print("Deliveries by format:\n", bbb['match_format'].value_counts())
print("\nDeliveries by season:\n", bbb['season'].value_counts())
