import pandas as pd
import numpy as np

p = r'C:\Users\mishr\.gemini\antigravity\scratch\superr_selector\Data Pack'
bbb = pd.read_csv(f'{p}/ball_by_ball.csv')
matches = pd.read_csv(f'{p}/matches.csv')

matches_dict = matches.set_index('match_id').to_dict(orient='index')

# Calculate total runs per ball:
bbb['ball_runs_total'] = bbb['runs'] + bbb['extras1_runs'] + bbb['extras_2_runs']
bbb['is_legal'] = ~bbb['extras_type'].isin(['wide', 'Overstep', 'other'])

# Sort properly
bbb = bbb.sort_values(['match_id', 'innings', 'overid', 'over_ball_num']).reset_index(drop=True)

# Compute innings targets
inn1_totals = bbb[bbb['innings'] == 1].groupby('match_id')['ball_runs_total'].sum().to_dict()

# Group cumulative
bbb['cum_runs'] = bbb.groupby(['match_id', 'innings'])['ball_runs_total'].cumsum() - bbb['ball_runs_total']
bbb['cum_legal_balls'] = bbb.groupby(['match_id', 'innings'])['is_legal'].cumsum() - bbb['is_legal'].astype(int)
bbb['cum_wickets'] = bbb.groupby(['match_id', 'innings'])['is_wicket'].cumsum() - bbb['is_wicket'].astype(int)

def classify_pressure(row):
    mid = row['match_id']
    m_info = matches_dict.get(mid, {})
    is_ko = m_info.get('knock_out', 0) == 1
    inn = row['innings']
    over = row['overid']
    cum_w = row['cum_wickets']
    balls_bowled = row['cum_legal_balls']
    balls_rem = max(0, 120 - balls_bowled)
    
    if inn == 1:
        if balls_bowled <= 36 and cum_w >= 3:
            return True, 'Inn1 Collapse (Powerplay)'
        if balls_bowled <= 60 and cum_w >= 4:
            return True, 'Inn1 Collapse (Middle)'
        if over >= 17:
            return True, 'Inn1 Death Overs (17-20)'
        if is_ko and over >= 15 and cum_w >= 3:
            return True, 'Inn1 Knockout Crunch'
        return False, 'Inn1 Normal'
    
    elif inn == 2:
        target = m_info.get('revised_target')
        if pd.isna(target) or target == 0:
            target = inn1_totals.get(mid, 0) + 1
        
        runs_needed = max(0, target - row['cum_runs'])
        
        if runs_needed <= 0 or balls_rem <= 0:
            return False, 'Inn2 Decided'
        
        rrr = (runs_needed * 6.0) / max(1, balls_rem)
        
        if balls_rem <= 60 and rrr >= 9.5:
            return True, 'Inn2 Steep RRR (>=9.5)'
        if balls_bowled > 36 and rrr >= 11.0:
            return True, 'Inn2 Extreme RRR (>=11.0)'
        if over >= 16 and runs_needed > 0 and rrr <= 24.0:
            return True, 'Inn2 Death Overs'
        if balls_bowled <= 36 and cum_w >= 3:
            return True, 'Inn2 Chase Collapse'
        if cum_w >= 6 and runs_needed > 15:
            return True, 'Inn2 Lower Order Pressure'
        if is_ko and over >= 14 and rrr >= 8.5:
            return True, 'Inn2 Knockout Chase'
        return False, 'Inn2 Normal'
    
    return False, 'Super Over / Other'

results = [classify_pressure(row) for _, row in bbb.iterrows()]
bbb['is_pressure'] = [r[0] for r in results]
bbb['pressure_tag'] = [r[1] for r in results]

total_balls = len(bbb)
pres_balls = bbb['is_pressure'].sum()
print(f"Total deliveries: {total_balls}")
print(f"Pressure deliveries: {pres_balls} ({pres_balls/total_balls*100:.2f}%)")
print("\nPressure tags breakdown:")
print(bbb['pressure_tag'].value_counts())
