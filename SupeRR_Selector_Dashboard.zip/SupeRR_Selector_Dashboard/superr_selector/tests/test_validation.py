"""
Validation and unit testing script for SupeRR Selector Dashboard.
Verifies data integrity, calculation consistency, and absence of NaN values.
"""

import sys
import os
pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if pkg_root not in sys.path:
    sys.path.insert(0, pkg_root)

import pandas as pd
import numpy as np
from src.config import DATA_PROCESSED_DIR
from src.models import calculate_batting_rankings, calculate_bowling_rankings

def test_pipeline():
    print("Testing data files existence...")
    assert os.path.exists(os.path.join(DATA_PROCESSED_DIR, "deliveries_processed.parquet")), "deliveries missing!"
    assert os.path.exists(os.path.join(DATA_PROCESSED_DIR, "matches_processed.parquet")), "matches missing!"
    assert os.path.exists(os.path.join(DATA_PROCESSED_DIR, "players_meta.parquet")), "players_meta missing!"

    print("Loading data...")
    bbb = pd.read_parquet(os.path.join(DATA_PROCESSED_DIR, "deliveries_processed.parquet"))
    pmeta = pd.read_parquet(os.path.join(DATA_PROCESSED_DIR, "players_meta.parquet"))

    print(f"Total deliveries: {len(bbb)}")
    assert len(bbb) == 200999, f"Expected 200999 balls, got {len(bbb)}"

    print("Testing Batting Rankings...")
    bat_r = calculate_batting_rankings(bbb, pmeta, min_pressure_balls=100)
    assert len(bat_r) >= 10, "Less than 10 qualified batters!"
    assert len(set(bat_r["striker_id"].head(10))) == 10, "Duplicate batters in Top 10!"
    assert not bat_r["reliability_score"].head(10).isna().any(), "NaN in Batting reliability scores!"

    top10_bat = bat_r.head(10)
    print("Top 10 Batters validated:")
    for idx, r in top10_bat.iterrows():
        print(f"  {r['rank']}. {r['striker_name']} ({r['role']}) - Score: {r['reliability_score']:.1f}")

    print("\nTesting Bowling Rankings...")
    bowl_r = calculate_bowling_rankings(bbb, pmeta, min_pressure_balls=100)
    assert len(bowl_r) >= 10, "Less than 10 qualified bowlers!"
    assert len(set(bowl_r["bowler_id"].head(10))) == 10, "Duplicate bowlers in Top 10!"
    assert not bowl_r["reliability_score"].head(10).isna().any(), "NaN in Bowling reliability scores!"

    top10_bowl = bowl_r.head(10)
    print("Top 10 Bowlers validated:")
    for idx, r in top10_bowl.iterrows():
        print(f"  {r['rank']}. {r['bowler_name']} ({r['role']}) - Score: {r['reliability_score']:.1f}")

    print("\nALL INTEGRITY CHECKS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    test_pipeline()
