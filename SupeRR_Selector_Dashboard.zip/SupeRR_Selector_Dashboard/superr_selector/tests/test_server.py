import subprocess
import time
import urllib.request
import sys
import os

cmd = [
    sys.executable, "-m", "streamlit", "run",
    r"C:\Users\mishr\.gemini\antigravity\scratch\superr_selector\app.py",
    "--server.headless", "true",
    "--server.port", "8501"
]

print("Starting Streamlit server...")
proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

try:
    time.sleep(5)
    url = "http://localhost:8501"
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req, timeout=5) as response:
        status = response.status
        content = response.read(500)
        print(f"SUCCESS: Server responded with HTTP status {status}!")
        print(f"Content preview: {len(content)} bytes received")
except Exception as e:
    print(f"Server probe failed: {e}")
    # Print process output
    proc.terminate()
    stdout, stderr = proc.communicate(timeout=3)
    print("STDOUT:", stdout)
    print("STDERR:", stderr)
finally:
    if proc.poll() is None:
        proc.terminate()
        proc.wait()
    print("Streamlit test server stopped cleanly.")
