import pandas as pd
import numpy as np

p = r'C:\Users\mishr\.gemini\antigravity\scratch\superr_selector\Data Pack'
bbb = pd.read_csv(f'{p}/ball_by_ball.csv')
matches = pd.read_csv(f'{p}/matches.csv')
comps = pd.read_csv(f'{p}/competitions.csv')
mapping = pd.read_csv(f'{p}/competition_team_player_mapping.csv')

# Link competitions
matches = matches.merge(comps[['comp_id', 'match_format', 'season', 'comp_name']], on='comp_id', how='left')
matches_dict = matches.set_index('match_id').to_dict(orient='index')

# Calculate ball totals
bbb['ball_runs_total'] = bbb['runs'] + bbb['extras1_runs'] + bbb['extras_2_runs']
bbb['is_legal'] = ~bbb['extras_type'].isin(['wide', 'Overstep', 'other'])
bbb['is_batter_ball'] = bbb['extras_type'] != 'wide'

# Sort
bbb = bbb.sort_values(['match_id', 'innings', 'overid', 'over_ball_num']).reset_index(drop=True)

# Innings totals
inn1_totals = bbb[bbb['innings'] == 1].groupby('match_id')['ball_runs_total'].sum().to_dict()

bbb['cum_runs'] = bbb.groupby(['match_id', 'innings'])['ball_runs_total'].cumsum() - bbb['ball_runs_total']
bbb['cum_legal_balls'] = bbb.groupby(['match_id', 'innings'])['is_legal'].cumsum() - bbb['is_legal'].astype(int)
bbb['cum_wickets'] = bbb.groupby(['match_id', 'innings'])['is_wicket'].cumsum() - bbb['is_wicket'].astype(int)

# Classify pressure
def classify_pressure(row):
    mid = row['match_id']
    m_info = matches_dict.get(mid, {})
    is_ko = m_info.get('knock_out', 0) == 1
    inn = row['innings']
    over = row['overid']
    cum_w = row['cum_wickets']
    balls_bowled = row['cum_legal_balls']
    balls_rem = max(0, 120 - balls_bowled)
    
    if inn == 1:
        if balls_bowled <= 36 and cum_w >= 3:
            return True
        if balls_bowled <= 60 and cum_w >= 4:
            return True
        if over >= 17:
            return True
        if is_ko and over >= 15 and cum_w >= 3:
            return True
        return False
    
    elif inn == 2:
        target = m_info.get('revised_target')
        if pd.isna(target) or target == 0:
            target = inn1_totals.get(mid, 0) + 1
        
        runs_needed = max(0, target - row['cum_runs'])
        if runs_needed <= 0 or balls_rem <= 0:
            return False
        
        rrr = (runs_needed * 6.0) / max(1, balls_rem)
        if balls_rem <= 60 and rrr >= 9.5:
            return True
        if balls_bowled > 36 and rrr >= 11.0:
            return True
        if over >= 16 and runs_needed > 0 and rrr <= 24.0:
            return True
        if balls_bowled <= 36 and cum_w >= 3:
            return True
        if cum_w >= 6 and runs_needed > 15:
            return True
        if is_ko and over >= 14 and rrr >= 8.5:
            return True
        return False
    
    return False

bbb['is_pressure'] = [classify_pressure(row) for _, row in bbb.iterrows()]

# Bowler runs conceded logic
def calc_bowler_runs(row):
    ext = row['extras_type']
    if pd.isna(ext):
        return row['runs']
    elif ext == 'wide':
        return row['extras1_runs']
    elif ext in ['Overstep', 'other']:
        return row['runs'] + row['extras1_runs']
    else: # legbyes, byes, penalty
        return 0

bbb['bowler_runs_conceded'] = [calc_bowler_runs(r) for _, r in bbb.iterrows()]
bbb['is_bowler_wicket'] = bbb['is_wicket'] & bbb['dismissal_type'].isin(['Caught', 'Bowled', 'LBW', 'Stump', 'Hit Wicket'])

print("Ball data prepared. Analyzing Batting...")

# BATTING AGGREGATION
def analyze_batting(df, is_pres):
    sub = df[df['is_pressure'] == is_pres]
    grp = sub.groupby(['striker_id', 'striker_name'])
    
    runs = grp['runs'].sum()
    balls = grp['is_batter_ball'].sum()
    dots = grp.apply(lambda g: ((g['runs'] == 0) & g['is_batter_ball']).sum())
    fours = grp['is_four'].sum()
    sixes = grp['is_six'].sum()
    
    # Dismissals: striker out
    outs = sub[sub['is_wicket'] & (sub['dismissed_player_id'] == sub['striker_id'])].groupby(['striker_id', 'striker_name']).size()
    
    res = pd.DataFrame({
        'runs': runs,
        'balls': balls,
        'dots': dots,
        'fours': fours,
        'sixes': sixes,
        'outs': outs
    }).fillna(0)
    
    res['sr'] = (res['runs'] / res['balls'].replace(0, np.nan)) * 100
    res['avg'] = res['runs'] / res['outs'].replace(0, np.nan)
    res['dot_pct'] = (res['dots'] / res['balls'].replace(0, np.nan)) * 100
    res['bdry_pct'] = ((res['fours'] + res['sixes']) / res['balls'].replace(0, np.nan)) * 100
    res['bdry_run_pct'] = ((res['fours']*4 + res['sixes']*6) / res['runs'].replace(0, np.nan)) * 100
    return res

bat_pres = analyze_batting(bbb, True)
bat_norm = analyze_batting(bbb, False)

# Filter minimum sample size: e.g. at least 60 balls under pressure and 150 balls overall
bat_merged = bat_pres.join(bat_norm, lsuffix='_pres', rsuffix='_norm', how='inner')
bat_merged['total_balls'] = bat_merged['balls_pres'] + bat_merged['balls_norm']
bat_merged['total_runs'] = bat_merged['runs_pres'] + bat_merged['runs_norm']

# Batting qualifiers
qual_bat = bat_merged[(bat_merged['balls_pres'] >= 75) & (bat_merged['total_balls'] >= 200)].copy()
print(f"Qualified Batters count: {len(qual_bat)}")

# BOWLING AGGREGATION
def analyze_bowling(df, is_pres):
    sub = df[df['is_pressure'] == is_pres]
    grp = sub.groupby(['bowler_id', 'bowler_name'])
    
    runs = grp['bowler_runs_conceded'].sum()
    balls = grp['is_legal'].sum()
    dots = grp.apply(lambda g: (g['is_legal'] & (g['bowler_runs_conceded'] == 0)).sum())
    fours = grp['is_four'].sum()
    sixes = grp['is_six'].sum()
    wkts = grp['is_bowler_wicket'].sum()
    
    res = pd.DataFrame({
        'runs_conceded': runs,
        'legal_balls': balls,
        'dots': dots,
        'fours_conceded': fours,
        'sixes_conceded': sixes,
        'wickets': wkts
    }).fillna(0)
    
    res['overs'] = res['legal_balls'] / 6.0
    res['econ'] = (res['runs_conceded'] / res['overs'].replace(0, np.nan))
    res['avg'] = res['runs_conceded'] / res['wickets'].replace(0, np.nan)
    res['sr'] = res['legal_balls'] / res['wickets'].replace(0, np.nan)
    res['dot_pct'] = (res['dots'] / res['legal_balls'].replace(0, np.nan)) * 100
    res['bdry_pct'] = ((res['fours_conceded'] + res['sixes_conceded']) / res['legal_balls'].replace(0, np.nan)) * 100
    return res

bowl_pres = analyze_bowling(bbb, True)
bowl_norm = analyze_bowling(bbb, False)

bowl_merged = bowl_pres.join(bowl_norm, lsuffix='_pres', rsuffix='_norm', how='inner')
bowl_merged['total_balls'] = bowl_merged['legal_balls_pres'] + bowl_merged['legal_balls_norm']
bowl_merged['total_wkts'] = bowl_merged['wickets_pres'] + bowl_merged['wickets_norm']

qual_bowl = bowl_merged[(bowl_merged['legal_balls_pres'] >= 75) & (bowl_merged['total_balls'] >= 200)].copy()
print(f"Qualified Bowlers count: {len(qual_bowl)}")

# Inspect top candidates
print("\nTop 15 Batters by Runs under pressure:")
print(qual_bat.sort_values('runs_pres', ascending=False)[['runs_pres', 'balls_pres', 'sr_pres', 'avg_pres', 'sr_norm', 'avg_norm']].head(15))

print("\nTop 15 Bowlers by Wickets under pressure:")
print(qual_bowl.sort_values('wickets_pres', ascending=False)[['wickets_pres', 'legal_balls_pres', 'econ_pres', 'avg_pres', 'econ_norm', 'avg_norm']].head(15))
