import pandas as pd
import numpy as np

p = r'C:\Users\mishr\.gemini\antigravity\scratch\superr_selector\Data Pack'
bbb = pd.read_csv(f'{p}/ball_by_ball.csv')
matches = pd.read_csv(f'{p}/matches.csv')
comps = pd.read_csv(f'{p}/competitions.csv')
mapping = pd.read_csv(f'{p}/competition_team_player_mapping.csv')
p11 = pd.read_csv(f'{p}/playing_eleven.csv')

# Merge match context
matches = matches.merge(comps[['comp_id', 'match_format', 'season', 'comp_name']], on='comp_id', how='left')
matches_dict = matches.set_index('match_id').to_dict(orient='index')

# Ball metrics
bbb['ball_runs_total'] = bbb['runs'] + bbb['extras1_runs'] + bbb['extras_2_runs']
bbb['is_legal'] = ~bbb['extras_type'].isin(['wide', 'Overstep', 'other'])
bbb['is_batter_ball'] = bbb['extras_type'] != 'wide'
bbb['is_dot_batter'] = (bbb['runs'] == 0) & bbb['is_batter_ball']

# Sort
bbb = bbb.sort_values(['match_id', 'innings', 'overid', 'over_ball_num']).reset_index(drop=True)

# Innings targets
inn1_totals = bbb[bbb['innings'] == 1].groupby('match_id')['ball_runs_total'].sum().to_dict()

bbb['cum_runs'] = bbb.groupby(['match_id', 'innings'])['ball_runs_total'].cumsum() - bbb['ball_runs_total']
bbb['cum_legal_balls'] = bbb.groupby(['match_id', 'innings'])['is_legal'].cumsum() - bbb['is_legal'].astype(int)
bbb['cum_wickets'] = bbb.groupby(['match_id', 'innings'])['is_wicket'].cumsum() - bbb['is_wicket'].astype(int)

def classify_pressure(row):
    mid = row['match_id']
    m_info = matches_dict.get(mid, {})
    is_ko = m_info.get('knock_out', 0) == 1
    inn = row['innings']
    over = row['overid']
    cum_w = row['cum_wickets']
    balls_bowled = row['cum_legal_balls']
    balls_rem = max(0, 120 - balls_bowled)
    
    if inn == 1:
        if balls_bowled <= 36 and cum_w >= 3:
            return True
        if balls_bowled <= 60 and cum_w >= 4:
            return True
        if over >= 17:
            return True
        if is_ko and over >= 15 and cum_w >= 3:
            return True
        return False
    
    elif inn == 2:
        target = m_info.get('revised_target')
        if pd.isna(target) or target == 0:
            target = inn1_totals.get(mid, 0) + 1
        
        runs_needed = max(0, target - row['cum_runs'])
        if runs_needed <= 0 or balls_rem <= 0:
            return False
        
        rrr = (runs_needed * 6.0) / max(1, balls_rem)
        if balls_rem <= 60 and rrr >= 9.5:
            return True
        if balls_bowled > 36 and rrr >= 11.0:
            return True
        if over >= 16 and runs_needed > 0 and rrr <= 24.0:
            return True
        if balls_bowled <= 36 and cum_w >= 3:
            return True
        if cum_w >= 6 and runs_needed > 15:
            return True
        if is_ko and over >= 14 and rrr >= 8.5:
            return True
        return False
    
    return False

bbb['is_pressure'] = [classify_pressure(row) for _, row in bbb.iterrows()]

# Bowler calculations
def calc_bowler_runs(row):
    ext = row['extras_type']
    if pd.isna(ext):
        return row['runs']
    elif ext == 'wide':
        return row['extras1_runs']
    elif ext in ['Overstep', 'other']:
        return row['runs'] + row['extras1_runs']
    else:
        return 0

bbb['bowler_runs_conceded'] = [calc_bowler_runs(r) for _, r in bbb.iterrows()]
bbb['is_bowler_wicket'] = bbb['is_wicket'] & bbb['dismissal_type'].isin(['Caught', 'Bowled', 'LBW', 'Stump', 'Hit Wicket'])
bbb['is_dot_bowler'] = bbb['is_legal'] & (bbb['bowler_runs_conceded'] == 0)

# Match level aggregations for consistency
# Batting match aggregates
bat_match = bbb[bbb['is_pressure']].groupby(['match_id', 'striker_id', 'striker_name']).agg(
    p_runs=('runs', 'sum'),
    p_balls=('is_batter_ball', 'sum')
).reset_index()
# Success match = SR >= 135 or runs >= 25 under pressure
bat_match['is_impact'] = (bat_match['p_runs'] >= 20) | ((bat_match['p_balls'] >= 8) & ((bat_match['p_runs']/bat_match['p_balls']) >= 1.4))
bat_consistency = bat_match.groupby(['striker_id', 'striker_name']).agg(
    pres_matches=('match_id', 'nunique'),
    impact_matches=('is_impact', 'sum')
).reset_index()
bat_consistency['consistency_rate'] = bat_consistency['impact_matches'] / bat_consistency['pres_matches']

# Bowling match aggregates
bowl_match = bbb[bbb['is_pressure']].groupby(['match_id', 'bowler_id', 'bowler_name']).agg(
    p_runs_c=('bowler_runs_conceded', 'sum'),
    p_balls_b=('is_legal', 'sum'),
    p_wkts=('is_bowler_wicket', 'sum')
).reset_index()
bowl_match['is_impact'] = (bowl_match['p_wkts'] >= 1) | ((bowl_match['p_balls_b'] >= 12) & ((bowl_match['p_runs_c'] / (bowl_match['p_balls_b']/6.0)) <= 8.0))
bowl_consistency = bowl_match.groupby(['bowler_id', 'bowler_name']).agg(
    pres_matches=('match_id', 'nunique'),
    impact_matches=('is_impact', 'sum')
).reset_index()
bowl_consistency['consistency_rate'] = bowl_consistency['impact_matches'] / bowl_consistency['pres_matches']

# Overall Batting Aggregation
def get_bat_stats(df, is_pres):
    sub = df[df['is_pressure'] == is_pres]
    grp = sub.groupby(['striker_id', 'striker_name'])
    
    runs = grp['runs'].sum()
    balls = grp['is_batter_ball'].sum()
    dots = grp['is_dot_batter'].sum()
    fours = grp['is_four'].sum()
    sixes = grp['is_six'].sum()
    
    striker_outs = sub[sub['is_wicket'] & (sub['dismissed_player_id'] == sub['striker_id'])].groupby(['striker_id', 'striker_name']).size()
    
    res = pd.DataFrame({
        'runs': runs,
        'balls': balls,
        'dots': dots,
        'fours': fours,
        'sixes': sixes
    }).join(striker_outs.rename('outs'), how='left').fillna(0)
    
    res['sr'] = (res['runs'] / res['balls'].replace(0, np.nan)) * 100
    res['avg'] = res['runs'] / res['outs'].replace(0, 1) # at least 1 for finite avg
    res['dot_pct'] = (res['dots'] / res['balls'].replace(0, np.nan)) * 100
    res['bdry_pct'] = ((res['fours'] + res['sixes']) / res['balls'].replace(0, np.nan)) * 100
    res['bdry_run_pct'] = ((res['fours']*4 + res['sixes']*6) / res['runs'].replace(0, np.nan)) * 100
    return res

bat_p = get_bat_stats(bbb, True)
bat_n = get_bat_stats(bbb, False)

bat_df = bat_p.join(bat_n, lsuffix='_pres', rsuffix='_norm', how='inner').reset_index()
bat_df = bat_df.merge(bat_consistency, on=['striker_id', 'striker_name'], how='left')

# Minimum sample qualification:
# e.g. at least 100 balls under pressure AND at least 250 total balls
bat_qual = bat_df[(bat_df['balls_pres'] >= 100) & (bat_df['balls_pres'] + bat_df['balls_norm'] >= 250)].copy()

# Batting Reliability Model Calculations
# 1. Delta metrics
bat_qual['delta_sr'] = bat_qual['sr_pres'] - bat_qual['sr_norm']
bat_qual['delta_avg'] = bat_qual['avg_pres'] - bat_qual['avg_norm']
bat_qual['delta_dot'] = bat_qual['dot_pct_norm'] - bat_qual['dot_pct_pres'] # positive is better

# Z-scores
def zscore(s):
    std = s.std()
    return (s - s.mean()) / (std if std != 0 else 1)

# Pressure performance Z
z_sr_p = zscore(bat_qual['sr_pres'])
z_avg_p = zscore(bat_qual['avg_pres'])
z_bdry_p = zscore(bat_qual['bdry_pct_pres'])
z_dot_p = -zscore(bat_qual['dot_pct_pres'])

score_perf_bat = 0.35 * z_sr_p + 0.35 * z_avg_p + 0.15 * z_bdry_p + 0.15 * z_dot_p

# Delta Z
z_dsr = zscore(bat_qual['delta_sr'])
z_davg = zscore(bat_qual['delta_avg'])
z_ddot = zscore(bat_qual['delta_dot'])

score_delta_bat = 0.40 * z_dsr + 0.40 * z_davg + 0.20 * z_ddot

# Consistency Z
z_const_bat = zscore(bat_qual['consistency_rate'].fillna(0))

# Composite Raw Score
composite_raw_bat = 0.45 * score_perf_bat + 0.30 * score_delta_bat + 0.25 * z_const_bat

# Bayesian Sample Credibility weight
# Prior N0 = 120 balls (about 20 overs of pressure facing)
w_bat = bat_qual['balls_pres'] / (bat_qual['balls_pres'] + 100.0)

# Credibility-adjusted score
bat_qual['raw_brs'] = w_bat * composite_raw_bat

# Normalize to 0-100 scale
min_s = bat_qual['raw_brs'].min()
max_s = bat_qual['raw_brs'].max()
bat_qual['reliability_score'] = ((bat_qual['raw_brs'] - min_s) / (max_s - min_s) * 45.0 + 55.0).round(2)
bat_qual = bat_qual.sort_values('reliability_score', ascending=False).reset_index(drop=True)
bat_qual['rank'] = range(1, len(bat_qual) + 1)

print("=== TOP 12 BATTERS UNDER PRESSURE ===")
cols_bat_show = ['rank', 'striker_name', 'reliability_score', 'runs_pres', 'balls_pres', 'sr_pres', 'avg_pres', 'delta_sr', 'delta_avg', 'consistency_rate']
print(bat_qual[cols_bat_show].head(12).to_string(index=False))

# BOWLING
def get_bowl_stats(df, is_pres):
    sub = df[df['is_pressure'] == is_pres]
    grp = sub.groupby(['bowler_id', 'bowler_name'])
    
    runs = grp['bowler_runs_conceded'].sum()
    balls = grp['is_legal'].sum()
    dots = grp['is_dot_bowler'].sum()
    fours = grp['is_four'].sum()
    sixes = grp['is_six'].sum()
    wkts = grp['is_bowler_wicket'].sum()
    
    res = pd.DataFrame({
        'runs_conceded': runs,
        'legal_balls': balls,
        'dots': dots,
        'fours_conceded': fours,
        'sixes_conceded': sixes,
        'wickets': wkts
    })
    
    res['overs'] = res['legal_balls'] / 6.0
    res['econ'] = res['runs_conceded'] / res['overs'].replace(0, np.nan)
    res['avg'] = res['runs_conceded'] / res['wickets'].replace(0, np.nan)
    res['sr'] = res['legal_balls'] / res['wickets'].replace(0, np.nan)
    res['dot_pct'] = (res['dots'] / res['legal_balls'].replace(0, np.nan)) * 100
    res['bdry_pct'] = ((res['fours_conceded'] + res['sixes_conceded']) / res['legal_balls'].replace(0, np.nan)) * 100
    return res

bowl_p = get_bowl_stats(bbb, True)
bowl_n = get_bowl_stats(bbb, False)

bowl_df = bowl_p.join(bowl_n, lsuffix='_pres', rsuffix='_norm', how='inner').reset_index()
bowl_df = bowl_df.merge(bowl_consistency, on=['bowler_id', 'bowler_name'], how='left')

# Death overs specific
bbb_death_pres = bbb[bbb['is_pressure'] & (bbb['overid'] >= 16)]
death_grp = bbb_death_pres.groupby(['bowler_id', 'bowler_name']).agg(
    death_balls=('is_legal', 'sum'),
    death_runs=('bowler_runs_conceded', 'sum'),
    death_wkts=('is_bowler_wicket', 'sum')
).reset_index()
death_grp['death_econ'] = (death_grp['death_runs'] / (death_grp['death_balls']/6.0).replace(0, np.nan))
bowl_df = bowl_df.merge(death_grp[['bowler_id', 'bowler_name', 'death_balls', 'death_econ', 'death_wkts']], on=['bowler_id', 'bowler_name'], how='left')

bowl_qual = bowl_df[(bowl_df['legal_balls_pres'] >= 100) & (bowl_df['legal_balls_pres'] + bowl_df['legal_balls_norm'] >= 250)].copy()

# Bowling Reliability Model Calculations
bowl_qual['delta_econ'] = bowl_qual['econ_norm'] - bowl_qual['econ_pres'] # positive is better (lower econ under pressure)
bowl_qual['delta_dot'] = bowl_qual['dot_pct_pres'] - bowl_qual['dot_pct_norm'] # positive is better
bowl_qual['delta_wkt_rate'] = (bowl_qual['wickets_pres'] / bowl_qual['legal_balls_pres']) - (bowl_qual['wickets_norm'] / bowl_qual['legal_balls_norm'])

z_econ_p = -zscore(bowl_qual['econ_pres']) # lower is better
z_wkts_p = zscore(bowl_qual['wickets_pres'] / bowl_qual['legal_balls_pres'])
z_dot_bowl_p = zscore(bowl_qual['dot_pct_pres'])
z_bdry_bowl_p = -zscore(bowl_qual['bdry_pct_pres'])

score_perf_bowl = 0.35 * z_econ_p + 0.30 * z_wkts_p + 0.20 * z_dot_bowl_p + 0.15 * z_bdry_bowl_p

z_decon = zscore(bowl_qual['delta_econ'])
z_ddot_b = zscore(bowl_qual['delta_dot'])
z_dwkt = zscore(bowl_qual['delta_wkt_rate'])

score_delta_bowl = 0.45 * z_decon + 0.30 * z_ddot_b + 0.25 * z_dwkt
z_const_bowl = zscore(bowl_qual['consistency_rate'].fillna(0))

composite_raw_bowl = 0.45 * score_perf_bowl + 0.30 * score_delta_bowl + 0.25 * z_const_bowl

w_bowl = bowl_qual['legal_balls_pres'] / (bowl_qual['legal_balls_pres'] + 100.0)
bowl_qual['raw_score'] = w_bowl * composite_raw_bowl

min_sb = bowl_qual['raw_score'].min()
max_sb = bowl_qual['raw_score'].max()
bowl_qual['reliability_score'] = ((bowl_qual['raw_score'] - min_sb) / (max_sb - min_sb) * 45.0 + 55.0).round(2)
bowl_qual = bowl_qual.sort_values('reliability_score', ascending=False).reset_index(drop=True)
bowl_qual['rank'] = range(1, len(bowl_qual) + 1)

print("\n=== TOP 12 BOWLERS UNDER PRESSURE ===")
cols_bowl_show = ['rank', 'bowler_name', 'reliability_score', 'wickets_pres', 'legal_balls_pres', 'econ_pres', 'avg_pres', 'delta_econ', 'consistency_rate']
print(bowl_qual[cols_bowl_show].head(12).to_string(index=False))
