"""
SupeRR Selector Season 2 | Round 1
Main Interactive Cricket Analytics Dashboard
Visual Identity: Official Rajasthan Royals Theme (Pastel Pink + Sky Blue + Dark Navy)
"""

import sys
import os

# Ensure package root is in sys.path
pkg_root = os.path.dirname(os.path.abspath(__file__))
if pkg_root not in sys.path:
    sys.path.insert(0, pkg_root)

import streamlit as st
import pandas as pd
import numpy as np

# Page configuration
st.set_page_config(
    page_title="SupeRR Selector | Cricket Intelligence",
    page_icon="🏏",
    layout="wide",
    initial_sidebar_state="expanded"
)

from src.config import (
    DATA_PROCESSED_DIR,
    COLOR_RR_PINK,
    COLOR_NAVY,
    BATTING_MIN_PRESSURE_BALLS,
    BATTING_MIN_TOTAL_BALLS,
    BOWLING_MIN_PRESSURE_BALLS,
    BOWLING_MIN_TOTAL_BALLS
)
from src.components import get_custom_css, get_base64_logo
from src.models import calculate_batting_rankings, calculate_bowling_rankings
from src.views.home import render_home_page
from src.views.batting import render_batting_page
from src.views.bowling import render_bowling_page
from src.views.comparison import render_comparison_page
from src.views.rankings import render_rankings_page
from src.views.methodology import render_methodology_page

# Inject CSS stylesheet
st.markdown(get_custom_css(), unsafe_allow_html=True)

# Data Loading with Zero-Copy Resource Caching
@st.cache_resource(show_spinner="Loading cricket intelligence datasets...")
def load_datasets():
    bbb = pd.read_parquet(os.path.join(DATA_PROCESSED_DIR, "deliveries_processed.parquet"))
    matches = pd.read_parquet(os.path.join(DATA_PROCESSED_DIR, "matches_processed.parquet"))
    comps = pd.read_parquet(os.path.join(DATA_PROCESSED_DIR, "competitions_processed.parquet"))
    players = pd.read_parquet(os.path.join(DATA_PROCESSED_DIR, "players_meta.parquet"))
    
    # Memory optimization: Convert repetitive string columns to category to save 50%+ RAM
    cat_cols = ["match_format", "season", "comp_name", "pressure_tag", "batting_type", "bowling_type", "dismissal_type", "pace_or_spin"]
    for col in cat_cols:
        if col in bbb.columns:
            bbb[col] = bbb[col].astype("category")

    return bbb, matches, comps, players

bbb_raw, matches_df, comps_df, player_meta_df = load_datasets()

# Sidebar Setup
with st.sidebar:
    logo_uri = get_base64_logo()
    st.markdown(f"""
    <div style="text-align: center; padding: 12px 0 16px 0;">
        <img src="{logo_uri}" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 8px;" />
        <div style="font-family: 'Outfit', sans-serif; font-size: 1.25rem; font-weight: 800; color: {COLOR_NAVY};">
            SupeRR <span style="color: {COLOR_RR_PINK};">Selector</span>
        </div>
        <div style="font-size: 0.75rem; color: #64748B; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">
            Season 2 • Round 1
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### 📌 Navigation")
    selected_page = st.radio(
        "Go to page:",
        [
            "🏠 Home / Overview",
            "🏏 Batting Under Pressure",
            "🎯 Bowling Under Pressure",
            "⚔️ Player Comparison",
            "🏅 Final Rankings",
            "📐 Methodology"
        ],
        index=0,
        label_visibility="collapsed"
    )

    st.markdown("---")
    st.markdown("### ⚙️ Analytical Filters")

    # Competition Format Filter
    format_choice = st.selectbox(
        "Match Format:",
        ["All Competitions", "IPL (Indian Premier League)", "T20I (Internationals)"]
    )

    # Season Filter
    available_seasons = sorted(list(set(bbb_raw["season"].dropna().unique())))
    season_choice = st.selectbox(
        "Season / Year:",
        ["All Seasons (2022–2026)"] + available_seasons
    )

    # Minimum Pressure Balls Slider
    min_balls_filter = st.slider(
        "Min. Pressure Balls Threshold:",
        min_value=50,
        max_value=250,
        value=100,
        step=10,
        help="Adjust minimum balls faced/bowled under pressure to qualify."
    )

    # Player Search Filter
    search_query = st.text_input("🔍 Quick Player Search:", placeholder="e.g. Suryakumar, Bumrah")

    st.markdown("---")
    st.markdown("### 📥 Submission Deliverables")

    ppt_path = os.path.join(pkg_root, "final_presentation", "Rajasthan_Royals_SupeRR_Selector_Presentation.pptx")
    if os.path.exists(ppt_path):
        with open(ppt_path, "rb") as f_ppt:
            st.download_button(
                label="📊 Download 10-Slide PPT (.pptx)",
                data=f_ppt.read(),
                file_name="Rajasthan_Royals_SupeRR_Selector_Presentation.pptx",
                mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                use_container_width=True
            )

    pdf_path = os.path.join(pkg_root, "Final_Methodology_Report.pdf")
    if os.path.exists(pdf_path):
        with open(pdf_path, "rb") as f_pdf:
            st.download_button(
                label="📄 Download Methodology PDF",
                data=f_pdf.read(),
                file_name="Final_Methodology_Report.pdf",
                mime="application/pdf",
                use_container_width=True
            )

    st.markdown("---")
    st.markdown("""
    <div style="font-size: 0.72rem; color: #64748B; line-height: 1.4; text-align: center;">
        Official Rajasthan Royals Cricket Intelligence Platform<br/>
        Data Coverage: 883 Matches • 200,999 Balls
    </div>
    """, unsafe_allow_html=True)

# Apply Filters to Deliveries Dataset
filtered_bbb = bbb_raw

if format_choice == "IPL (Indian Premier League)":
    filtered_bbb = filtered_bbb[filtered_bbb["match_format"] == "T20"]
elif format_choice == "T20I (Internationals)":
    filtered_bbb = filtered_bbb[filtered_bbb["match_format"] == "T20I"]

if season_choice != "All Seasons (2022–2026)":
    filtered_bbb = filtered_bbb[filtered_bbb["season"] == season_choice]

# Calculate dynamic rankings based on active filters (leading underscore skips costly DataFrame hashing)
@st.cache_data(show_spinner=False)
def get_cached_rankings(_deliveries_subset, min_balls, format_tag, season_tag):
    bat_r = calculate_batting_rankings(
        _deliveries_subset,
        player_meta_df,
        min_pressure_balls=min_balls,
        min_total_balls=min_balls * 2
    )
    bowl_r = calculate_bowling_rankings(
        _deliveries_subset,
        player_meta_df,
        min_pressure_balls=min_balls,
        min_total_balls=min_balls * 2
    )
    return bat_r, bowl_r

bat_rankings, bowl_rankings = get_cached_rankings(filtered_bbb, min_balls_filter, format_choice, str(season_choice))

# Apply player search filter if present
if search_query.strip():
    q = search_query.strip().lower()
    bat_rankings_display = bat_rankings[bat_rankings["striker_name"].str.lower().str.contains(q)]
    bowl_rankings_display = bowl_rankings[bowl_rankings["bowler_name"].str.lower().str.contains(q)]
else:
    bat_rankings_display = bat_rankings
    bowl_rankings_display = bowl_rankings

# Routing to Selected View
if selected_page == "🏠 Home / Overview":
    render_home_page(filtered_bbb, matches_df, comps_df, player_meta_df, bat_rankings_display, bowl_rankings_display)

elif selected_page == "🏏 Batting Under Pressure":
    render_batting_page(bat_rankings_display, filtered_bbb)

elif selected_page == "🎯 Bowling Under Pressure":
    render_bowling_page(bowl_rankings_display, filtered_bbb)

elif selected_page == "⚔️ Player Comparison":
    render_comparison_page(bat_rankings, bowl_rankings, filtered_bbb)

elif selected_page == "🏅 Final Rankings":
    render_rankings_page(bat_rankings_display, bowl_rankings_display)

elif selected_page == "📐 Methodology":
    render_methodology_page()
