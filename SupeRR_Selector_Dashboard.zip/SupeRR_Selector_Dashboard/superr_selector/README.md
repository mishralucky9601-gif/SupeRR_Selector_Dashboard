# SupeRR Selector Season 2 | Round 1
## Professional Cricket Analytics Dashboard: Performance Under Pressure

Interactive sports intelligence dashboard built for **Rajasthan Royals' SupeRR Selector Season 2 (Round 1)** competition.

---

### Features & Capabilities

- **Authentic Rajasthan Royals Visual Identity**: Pastel pink (`#FCE4EF`) mixed with light sky blue (`#DCEEFF`), subtle gradients, clean navy typography (`#182B49`), and official Rajasthan Royals crest logo.
- **Dynamic Delivery-Level Match State Engine**: Tracks cumulative runs, legal balls, wickets down, required run rate ($RRR$), and match stakes across 200,999 deliveries and 883 matches (2022–2026).
- **Objective Mathematical Models**:
  - **Batting Reliability Score (BRS)**
  - **Bowling Reliability Score (BowRS)**
  - Normal vs Pressure Baseline Differentials ($\Delta SR, \Delta Avg, \Delta Econ, \Delta Dot\%$)
  - Empirical Bayes Credibility Shrinkage ($w = \frac{N}{N + 100}$)
- **6 Comprehensive Dashboard Pages**:
  1. `🏠 Home / Overview`: Hero section, total matches analysed, total players, total pressure deliveries, KPI cards, and pressure distribution.
  2. `🏏 Batting Under Pressure`: Top 10 batters, SR comparison, efficiency scatter, and individual delivery-level drilldowns.
  3. `🎯 Bowling Under Pressure`: Top 10 bowlers, economy suppression, death-overs containment (overs 16–20), and dismissal modes.
  4. `⚔️ Player Comparison`: Head-to-head multi-player radar comparison (2 to 4 players), stacked volume charts, and scout reports.
  5. `🏅 Final Rankings`: Official Top 10 Batters and Bowlers with one-click CSV export buttons ready for Unstop submission dropdowns.
  6. `📐 Methodology`: In-depth analytical documentation with LaTeX math equations, scoring weights, and assumptions.
- **Interactive Global Filters**:
  - Match Format (All, IPL Only, T20I Only)
  - Season / Year (All, 2022, 2023, 2024, 2025, 2026)
  - Minimum Pressure Balls Slider (50 to 250 balls)
  - Real-time Player Search

---

### Project Structure

```
superr_selector/
├── app.py                     # Main Streamlit Dashboard Application
├── requirements.txt           # Python dependencies
├── README.md                  # Project overview & running instructions
├── METHODOLOGY.md             # Detailed Competition Methodology Report
├── assets/
│   └── rajasthan_royals_logo.svg  # Official Rajasthan Royals vector logo
├── data/                      # Processed parquet files for sub-second loading
│   ├── deliveries_processed.parquet
│   ├── matches_processed.parquet
│   ├── competitions_processed.parquet
│   └── players_meta.parquet
├── src/
│   ├── __init__.py
│   ├── config.py              # Brand colors, thresholds, and paths
│   ├── data_engine.py         # Live match state tracking & pressure tagging
│   ├── models.py              # Batting & Bowling Reliability Scoring models
│   ├── components.py          # Custom CSS, hero card, KPI cards, Plotly theme
│   └── views/
│       ├── __init__.py
│       ├── home.py            # Page 1: Home / Overview
│       ├── batting.py         # Page 2: Batting Under Pressure
│       ├── bowling.py         # Page 3: Bowling Under Pressure
│       ├── comparison.py      # Page 4: Player Comparison
│       ├── rankings.py        # Page 5: Final Rankings & CSV Export
│       └── methodology.py     # Page 6: Methodology & Math Formulations
└── tests/
    └── test_validation.py     # Data validation & scoring unit tests
```

---

### Quick Start Instructions

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Preprocess Data (Already generated)**:
   ```bash
   python src/data_engine.py
   ```

3. **Launch Dashboard**:
   ```bash
   streamlit run app.py
   ```

4. **Access in Browser**:
   Open `http://localhost:8501` to explore the dashboard.
