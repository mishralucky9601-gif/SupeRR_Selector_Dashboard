# SupeRR Selector Season 2 | Round 1
## Official Methodology Report: Performance Under Pressure

**Challenge:** Identify and Rank the Most Reliable Batters and Bowlers Under Pressure  
**Data Coverage:** Historical IPL and T20 International (T20I) Matches (2022–2026)  
**Dataset Scope:** 883 Matches | 200,999 Deliveries | 1,217 Tracked Players  

---

### Executive Summary

In T20 cricket, standard career aggregates (such as raw batting average or overall bowling economy) obscure how players react when the game is on the line. A boundary struck in a comfortable 10-an-over powerplay chase differs fundamentally from a boundary needed when the required run rate has climbed to 13.5 in the 18th over with six wickets down.

To distinguish true clutch performers from front-runners, we designed a **delivery-level pressure classification engine** and two multi-factor, standardized scoring models:
1. **Batting Reliability Score (BRS)**
2. **Bowling Reliability Score (BowRS)**

The system integrates:
- Dynamic match-situation pressure triggers (Required Run Rate, balls remaining, wickets in hand, innings stage, match stakes).
- Individual baseline differentials ($\Delta SR, \Delta Avg, \Delta Econ, \Delta Dot\%$).
- Match-to-match consistency distributions.
- Bayesian credibility shrinkage ($w = \frac{N}{N + N_0}$) to penalize sample volatility without discarding high-performing specialists.

---

### 1. Defining "Pressure" at the Delivery Level

Pressure in T20 cricket is asymmetric between Innings 1 (Target Setting) and Innings 2 (The Chase). Every delivery in the 200,999 ball dataset is classified using live match state variables:

#### A. Innings 2: Run Chase Mechanics
In the second innings, the exact target is known. At ball $t$:
$$\text{Runs Needed}_t = \max(0, \text{Target} - \text{Cumulative Runs}_t)$$
$$\text{Balls Remaining}_t = \max(0, 120 - \text{Cumulative Legal Balls}_t)$$
$$\text{Required Run Rate } (RRR_t) = \frac{\text{Runs Needed}_t \times 6}{\max(1, \text{Balls Remaining}_t)}$$

A delivery is classified as **High Pressure** if:
1. **Steep Run Rate Escalation ($RRR_t \ge 9.5$)**: In the second half of the chase ($\text{Balls Remaining} \le 60$).
2. **Extreme Rate Pressure ($RRR_t \ge 11.0$)**: At any point after the Powerplay ($\text{Balls Bowled} > 36$).
3. **Death-Overs Finish**: Overs 16–20 ($\text{Over} \ge 16$) where the match is actively alive ($\text{Runs Needed} > 0$ and $RRR_t \le 24.0$).
4. **Powerplay Top-Order Collapse**: 3+ wickets lost in the first 6 overs ($\text{Balls Bowled} \le 36 \land \text{Wickets Lost} \ge 3$).
5. **Lower-Order Vulnerability**: 6+ wickets lost ($\text{Wickets Lost} \ge 6$) with $>15$ runs remaining.
6. **Knockout Stage Pressure**: In playoff/eliminator/final matches ($\text{Knockout} = 1$), over $\ge 14$ and $RRR \ge 8.5$.

#### B. Innings 1: Target Setting Mechanics
In the first innings, pressure arises from severe collapse or high-stakes death acceleration:
1. **Powerplay Rebuild Crisis**: 3+ wickets down inside the first 6 overs ($\le 36$ balls).
2. **Middle-Overs Collapse**: 4+ wickets down inside the first 10 overs ($\le 60$ balls).
3. **Death Overs Finishing**: Overs 17 to 20 ($\text{Over} \ge 17$), where maximum scoring velocity is required by batters and boundary containment/yorkers by bowlers.
4. **Knockout Matches**: Over $\ge 15$ with 3+ wickets lost in knockout fixtures.

**Empirical Result:** Out of 200,999 deliveries, exactly **67,054 deliveries (33.36%)** are classified as Pressure, providing a statistically robust sample while cleanly filtering down to decisive match moments.

---

### 2. Official Top 10 Player Rankings

These rankings represent the official submission for Unstop dropdown selections:

#### Top 10 Batters Under Pressure

| Rank | Player Name | Role | Reliability Score (BRS) | Pressure Runs | Pressure Balls | Pressure SR | Pressure Avg | Boundary % | Dot % | SR Delta ($\Delta$) | Match Consistency |
|:---:|:---|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **1** | **Shashank Singh** | Middle-Order Batter | **100.00** | 734 | 398 | 184.4 | 56.5 | 23.9% | 29.4% | +78.9 | 48.5% |
| **2** | **Matthew Wade** | WK-Batter | **92.52** | 379 | 239 | 158.6 | 54.1 | 18.8% | 27.6% | +45.3 | 57.9% |
| **3** | **Ashutosh Sharma** | Middle-Order Batter | **91.57** | 530 | 293 | 180.9 | 27.9 | 24.2% | 33.1% | +93.9 | 53.8% |
| **4** | **Naman Dhir** | Middle-Order Batter | **91.52** | 505 | 245 | 206.1 | 29.7 | 26.5% | 29.8% | +64.6 | 53.3% |
| **5** | **Donovan Ferreira** | All-Rounder | **91.06** | 421 | 223 | 188.8 | 32.4 | 26.0% | 34.1% | +71.3 | 54.5% |
| **6** | **Babar Azam** | Top-Order Batter | **90.82** | 335 | 184 | 182.1 | 41.9 | 25.0% | 27.2% | +57.9 | 53.3% |
| **7** | **Suryakumar Yadav** | Middle-Order Batter | **90.49** | 1,474 | 793 | 185.9 | 38.8 | 26.2% | 26.9% | +27.3 | 56.5% |
| **8** | **Tristan Stubbs** | Middle-Order Batter | **89.55** | 1,099 | 648 | 169.6 | 40.7 | 21.6% | 29.8% | +49.1 | 50.9% |
| **9** | **Najibullah Zadran** | Middle-Order Batter | **88.55** | 285 | 162 | 175.9 | 47.5 | 22.8% | 29.0% | +79.4 | 41.2% |
| **10** | **Tim David** | Middle-Order Batter | **88.24** | 1,401 | 723 | 193.8 | 34.2 | 26.1% | 33.2% | +39.3 | 47.4% |

#### Top 10 Bowlers Under Pressure

| Rank | Player Name | Role | Reliability Score (BowRS) | Pressure Wkts | Pressure Balls | Pressure Econ | Pressure Avg | Dot % | Econ Delta ($\Delta$) | Death Econ (16-20) | Match Consistency |
|:---:|:---|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **1** | **Sufiyan Muqeem** | Bowler | **100.00** | 16 | 229 | 5.66 | 13.5 | 49.3% | +0.61 | 6.00 | 66.7% |
| **2** | **Mohammad Nawaz** | All-Rounder | **99.27** | 24 | 245 | 6.15 | 10.5 | 45.3% | +1.29 | 7.00 | 53.6% |
| **3** | **Abrar Ahmed** | Bowler | **97.64** | 19 | 284 | 6.13 | 15.3 | 45.4% | +0.89 | 6.86 | 66.7% |
| **4** | **Akeal Hosein** | Bowler | **95.11** | 26 | 284 | 6.57 | 12.0 | 44.0% | +1.41 | 8.57 | 52.8% |
| **5** | **Hasan Mahmud** | Bowler | **95.00** | 14 | 149 | 7.25 | 12.9 | 43.0% | +0.89 | 8.57 | 62.5% |
| **6** | **Abbas Afridi** | Bowler | **94.98** | 18 | 146 | 9.08 | 12.3 | 39.0% | -1.11 | 9.08 | 88.2% |
| **7** | **Matheesha Pathirana**| Bowler | **94.90** | 60 | 649 | 9.03 | 16.3 | 40.7% | -0.47 | 9.20 | 72.0% |
| **8** | **Zakary Foulkes** | Bowler | **94.77** | 13 | 134 | 7.97 | 13.7 | 44.8% | +2.31 | 8.65 | 66.7% |
| **9** | **Rasikh Salam** | Bowler | **94.27** | 28 | 287 | 9.22 | 15.8 | 38.0% | +0.76 | 9.38 | 73.9% |
| **10** | **Rashid Khan** | All-Rounder | **93.71** | 79 | 932 | 7.89 | 15.5 | 40.0% | -0.70 | 8.84 | 62.9% |

*(Note: High-volume elite masters like Jasprit Bumrah (50 pressure wkts, 7.42 econ) and Yuzvendra Chahal (69 pressure wkts) feature immediately following in the top echelon).*

---

### 3. Reliability Scoring Models & Mathematical Formulations

#### 3.1 Batting Reliability Score (BRS)

Let $Z(X) = \frac{X - \mu_X}{\sigma_X}$ denote the standardized Z-score of metric $X$ across all qualified batters.

1. **Pressure Performance Component ($S_{perf}, 45\%$)**:
   $$S_{perf} = 0.35 \cdot Z(SR_{pres}) + 0.35 \cdot Z(Avg_{pres}) + 0.15 \cdot Z(Bdry\%_{pres}) - 0.15 \cdot Z(Dot\%_{pres})$$

2. **Clutch Differential Component ($S_{delta}, 30\%$)**:
   Measures elevation above the player's own baseline:
   $$\Delta SR = SR_{pres} - SR_{norm}$$
   $$\Delta Avg = Avg_{pres} - Avg_{norm}$$
   $$\Delta Dot\% = Dot\%_{norm} - Dot\%_{pres} \quad (\text{positive if dots decreased})$$
   $$S_{delta} = 0.40 \cdot Z(\Delta SR) + 0.40 \cdot Z(\Delta Avg) + 0.20 \cdot Z(\Delta Dot\%)$$

3. **Match Consistency Component ($S_{const}, 25\%$)**:
   Measures recurrence across matches:
   $$\text{Consistency Rate} = \frac{\text{Matches with } (Runs \ge 20 \lor SR \ge 140 \text{ on } \ge 8 \text{ balls})}{\text{Total Matches with Pressure Faced}}$$
   $$S_{const} = Z(\text{Consistency Rate})$$

4. **Empirical Bayes Credibility Shrinkage ($w_{cred}$)**:
   Accounts for sample size $N_{pres}$ against Bayesian prior $N_0 = 100$ balls:
   $$w_{cred} = \frac{N_{pres}}{N_{pres} + N_0}$$
   $$\text{Raw BRS} = w_{cred} \times \left( 0.45 \cdot S_{perf} + 0.30 \cdot S_{delta} + 0.25 \cdot S_{const} \right)$$
   Scaled min-max onto $55.0 - 100.0$ for standardized dashboard display.

---

#### 3.2 Bowling Reliability Score (BowRS)

1. **Pressure Performance Component ($S_{perf}, 45\%$)**:
   $$S_{perf} = 0.35 \cdot (-Z(Econ_{pres})) + 0.30 \cdot Z(WktRate_{pres}) + 0.20 \cdot Z(Dot\%_{pres}) - 0.15 \cdot Z(BdryConceded\%_{pres})$$

2. **Clutch Differential Component ($S_{delta}, 30\%$)**:
   $$\Delta Econ = Econ_{norm} - Econ_{pres} \quad (\text{positive if economy tightened})$$
   $$\Delta Dot\% = Dot\%_{pres} - Dot\%_{norm}$$
   $$\Delta WktRate = \left(\frac{Wkts}{Balls}\right)_{pres} - \left(\frac{Wkts}{Balls}\right)_{norm}$$
   $$S_{delta} = 0.45 \cdot Z(\Delta Econ) + 0.30 \cdot Z(\Delta Dot\%) + 0.25 \cdot Z(\Delta WktRate)$$

3. **Match Consistency & Death Overs ($S_{const}, 25\%$)**:
   $$\text{Consistency Rate} = \frac{\text{Matches with } (Wkts \ge 1 \lor [Balls \ge 12 \land Econ \le 8.0])}{\text{Total Pressure Matches Bowled}}$$
   $$S_{const} = Z(\text{Consistency Rate})$$

4. **Bayesian Sample Shrinkage**:
   Prior $B_0 = 100$ legal deliveries:
   $$w_{cred} = \frac{B_{pres}}{B_{pres} + B_0}$$
   $$\text{Raw BowRS} = w_{cred} \times \left( 0.45 \cdot S_{perf} + 0.30 \cdot S_{delta} + 0.25 \cdot S_{const} \right)$$

---

### 4. Fair Comparisons, Eligibility & Sample Rules

1. **Minimum Sample Threshold**:
   - Qualified Batters: $\ge 100$ balls faced under pressure AND $\ge 250$ total balls.
   - Qualified Bowlers: $\ge 100$ legal balls bowled under pressure AND $\ge 250$ total balls.
2. **Format Integration**:
   - Both IPL and T20Is are elite franchise and international competitions with comparable tactical demands. The dashboard allows dynamic filtering by IPL Only, T20I Only, or Combined.
3. **No Duplicate Players**:
   - All players are uniquely tracked by `player_id` to prevent conflation between players sharing names (e.g. Rashid Khan leg-spinner vs batter).

---

### 5. Application Architecture & Reproducibility

The dashboard is built as an interactive sports research application using Streamlit, Plotly, Pandas, and Parquet caching:
- `app.py`: Main dashboard application with sidebar filters and page routing.
- `src/config.py`: Theme variables and mathematical hyperparameters.
- `src/data_engine.py`: Reconstructs live match states and performs pressure tagging.
- `src/models.py`: Calculates Batting & Bowling Reliability Scores and rankings.
- `src/components.py`: Custom CSS, authentic crest logo embedding, and Plotly templates.
- `src/views/`: 6 dedicated modular pages (Home, Batting, Bowling, Comparison, Rankings, Methodology).
